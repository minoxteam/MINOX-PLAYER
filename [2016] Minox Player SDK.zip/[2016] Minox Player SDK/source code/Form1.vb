﻿'Minox Player
'developer: Amar Tufo
'v2.3.0.3
'licenca: GNU/GPL v2.0
'posljednja implemnetirana funkcija: Zakrpa za playlistu sa ekstenzijom
'opis: Omogućava korisniku da spasi i učita playlistu po zatvaranju i podizanju programa
'kreirana je ekstenzija za playlistu .minox tipa .minoxfile
'nedostaje indexCounter: broji datoteke u playlisti od 1 ... n
'(C)2013, Amar Tufo & Minox Player
Imports WMPLib
Imports AxWMPLib
Imports System.IO
Imports XComponent.SliderBar.MACTrackBar
Imports gTrackBar
Imports Minox_Player
Imports System.Runtime
Imports System.Runtime.CompilerServices.AccessedThroughPropertyAttribute
Imports Microsoft.Win32
Imports System.Security.Permissions
Public Class Form1

    Inherits System.Windows.Forms.Form
    Public Sub New()
        Try

            InitializeComponent()
            Styler.Renderer = New MyRenderer()

            MinoxAgent.Renderer = New MyRenderer()
            ' MenuStrip1.Renderer = New MyRenderer()
            Form2.playlistMenu.Renderer = New MyRenderer()
        Catch ex As Exception

        End Try

    End Sub
    Dim a, b As Integer
    Dim msdwn As Boolean = False
    Dim MinoxPlayer As New AxWindowsMediaPlayer
    Dim volumeSlider As New XComponent.SliderBar.MACTrackBar
    Dim trackSlider As New gTrackBar.gTrackBar
    Dim mediaList As New List(Of String)
    Dim playlist As Collections.ObjectModel.ReadOnlyCollection(Of String)
    'Private myListBoxItemsFile As String = "C:\playlist.txt" '// your file.
    Dim w As IO.StreamWriter
    Dim r As IO.StreamReader
    Dim args As String()
    Public Number As Integer
    Public Sub ChecAssocation()
        'postavljam ekstenziju playliste na tip .minox sa zadanom ikonom Minox Player-a
        'ovdje sam imao jednu grešku, naime .NET Framework 3.5 SP1 pod kojim razvijam
        'Minox Player je tražio da pokrenem program kao admin u namjeri da bi registrovao
        'ekstenziju i kljuć za playlistu pod imenom .minox i ekstenziju tipa .minoxfile
        'ta greška je sada rješena; ovde nedostaje ekstenzija za otvaranje .mp3 datoteka
        'na klik miša, ili onda kada korisnik dobaci .mp3 pjesmu na ikonu minox player-a
        '********************************************************************************
        'posljednje izmjene u kodu su obavljene 9 semptembra, 2013 godine, Ponedljak
        'Minox Player
        'developer: Amar Tufo
        'v: 2.3.0.3 GNU/GPL v2.0
        '(c)2013, Amar Tufo & Minox Player
        My.Computer.Registry.ClassesRoot.CreateSubKey(".minox").SetValue("", "minoxfile")
        My.Computer.Registry.ClassesRoot.CreateSubKey("minoxfile\shell\open\" & "command").SetValue("", Application.ExecutablePath & " %1")
        My.Computer.Registry.ClassesRoot.CreateSubKey("minoxfile\DefaultIcon").SetValue("", Application.ExecutablePath)
    End Sub
    Public Class MyRenderer
        Inherits ToolStripProfessionalRenderer
        Protected Overloads Overrides Sub OnRenderMenuItemBackground(ByVal e As ToolStripItemRenderEventArgs)
            Try
                Dim rc As New Rectangle(Point.Empty, e.Item.Size)
                Dim c As Color = IIf(e.Item.Selected, Color.Red, Color.Transparent)
                Using brush As New SolidBrush(c)
                    e.Graphics.FillRectangle(brush, rc)
                End Using
            Catch ex As Exception

            End Try

        End Sub
    End Class

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        'deploying Timer1 play mode
        'Timer1 kontrola urađena uspješno
        '@uthor: Amar Tufo
        'verzija ispravke:playBack() v1.0.1
        'MinoxPlayer(c) 2013, Amar Tufo
        'Dim s = Form2.PlayList1.SelectedIndex = (0)
        'Dim f = Form2.Playlist.SelectedIndex = (0)
        'Form2.PlayList1.SelectedIndex = Form2.Playlist.SelectedIndex
        'Form2.Playlist.SelectedIndex = -1
        nowPlayling.Text = System.IO.Path.GetFileName(Form2.Playlist.SelectedItem)
        If MediaPlayer.playState = WMPLib.WMPPlayState.wmppsStopped Then
            ' Timer3.Start()
            'NextTrack()
            nowPlayling.Text = System.IO.Path.GetFileName(Form2.Playlist.SelectedItem)
            Timer2.Stop()
            gTrackBar1.Value = 0
            maxValue.Text = "00:00"
            minValue.Text = "00:00"
            'repeatPlaylistMode for Minox Player
            'version: v2.3.0.3
            'developer: Amar Tufo
            'MinoxPlayer(C)2013
            'MinoxPlayer SDK v2.3.0.3 update 20March,2013;
            'this function repeatPlaylist until the repeatPlaylistBox is checked
            If Form3.PlayItems.Checked = True Then
                Try
                    Form2.Playlist.SelectedIndex = Form2.Playlist.SelectedIndex + 1
                    MediaPlayer.URL = Form2.Playlist.SelectedItem
                    Play()
                    
                Catch ex As Exception
                    Form2.Playlist.SelectedIndex = (0)
                    MediaPlayer.URL = Form2.Playlist.SelectedItem
                    Play()
                End Try
                '***************************************************************
            ElseIf Form3.PlayItems.Checked = False Then
                'this condition is not yet fully defined;
                nowPlayling.Text = System.IO.Path.GetFileName(Form2.Playlist.SelectedItem)
                NextTrack()
                StopPlay()
            End If

        ElseIf MediaPlayer.playState = WMPPlayState.wmppsPlaying Then
            Timer2.Start()
            'NextTrack()
        End If
        Try
        Catch ex As Exception
            '****************
            MediaPlayer.URL = ""
            'Txt_TrackName.Text = Form2.Playlist.SelectedItem
        End Try

    End Sub
    'declaring function StopPlay()
    Public Sub StopPlay()
        Timer2.Stop()
        gTrackBar1.Value = 0
        minValue.Text = "00:00"
        maxValue.Text = "00:00"
    End Sub
    'creating NextTrack control
    Private Sub NextTrack()
        Try
            Dim s = Form2.PlayList1.SelectedIndex
            Dim f = Form2.Playlist.SelectedIndex
            Form2.PlayList1.SelectedIndex = s + 1
            Form2.Playlist.SelectedIndex = f + 1
            NotifyIcon1.Visible = True
            NotifyIcon1.ShowBalloonTip(3000, "Now playing:", System.IO.Path.GetFileName(Form2.Playlist.SelectedItem), ToolTipIcon.Info)
            Play()
        Catch ex As Exception
            MediaPlayer.URL = ""
            Play1.Text = "  Play"
        End Try
    End Sub
    'creating PreviousTrack control
    Private Sub PreviousTrack()
        Try
            Dim s = Form2.PlayList1.SelectedIndex
            Dim f = Form2.Playlist.SelectedIndex
            Form2.PlayList1.SelectedIndex = s - 1
            Form2.Playlist.SelectedIndex = f - 1
            NotifyIcon1.Visible = True
            NotifyIcon1.ShowBalloonTip(3000, "Now playing:", System.IO.Path.GetFileName(Form2.Playlist.SelectedItem), ToolTipIcon.Info)
            Play()
        Catch ex As Exception
            MediaPlayer.URL = ""
            Play1.Text = "  Play"
        End Try

    End Sub
    'declaring Play() sub procedure_______
    Private Sub Play()
        Try
            Timer2.Enabled = True
            Timer3.Enabled = True
            If MediaPlayer.playState = WMPLib.WMPPlayState.wmppsPaused Then
                MediaPlayer.Ctlcontrols.play()
            Else
                'deploying notification of minoxPlaybakcEngine
                NotifyIcon1.Visible = True
                NotifyIcon1.ShowBalloonTip(3000, "Now playing:", System.IO.Path.GetFileName(Form2.Playlist.SelectedItem), ToolTipIcon.Info)
                MediaPlayer.URL = Form2.PlayList1.SelectedItem
            End If
            Play1.Text = "Pause"
        Catch ex As Exception

        End Try

    End Sub
    Private Sub btnPlay_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_Play.Click

        btn_Play.Image = My.Resources.playback_play_icon_48
        'MsgBox("No song")
        'Timer2.Stop() '/in case when there is nothing to play
        '*******************
        'player will not reset the timer's
        'opros My.Computer.Audio.Play(My.Resources.btn_EStart, AudioPlayMode.Background)
        Timer5.Enabled = True
        trackStatus.Visible = True
        nowPlayling.Visible = True
        nowPlayling.Text = System.IO.Path.GetFileName(Form2.Playlist.SelectedItem)
        NotifyIcon1.Visible = True
        NotifyIcon1.ShowBalloonTip(3000, "Now playing:", System.IO.Path.GetFileName(Form2.Playlist.SelectedItem), ToolTipIcon.Info)
        'when minox player start's the track it will change the image into pause;
        'trackStatus.Image = My.Resources.pause
        'trackStatus.ImageAlign = ContentAlignment.MiddleLeft

        'End Region
        Try

            If MediaPlayer.playState = WMPPlayState.wmppsPaused Then
                'else the minox player is paused it will change the image into play
                Timer7.Enabled = False
                MediaPlayer.Ctlcontrols.play()
            Else
                StopPlay()

                MediaPlayer.URL = Form2.PlayList1.SelectedItem
            End If

            If Me.Text = System.IO.Path.GetFileName(Form2.PlayList1.SelectedItem) Then
                Timer2.Start()
            Else
                Try

                    'Ako nema pjesama na playlisti program neće zapoćeti produkciju
                    'licenca: AmarTufo
                    'verzija greške: playFunction v1.0.0

                Catch ex As Exception
                    Timer2.Stop()
                    gTrackBar1.Value = 0
                    maxValue.Text = "00:00"
                    minValue.Text = "00:00"
                End Try
            End If
        Catch ex As Exception


        End Try
    End Sub


    Private Sub FullMode_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FullMode.Click
        Try
            If FullMode.Text = "Full" Then
                MediaPlayer.uiMode = "Full"
                FullMode.Text = "None"
            Else
                MediaPlayer.uiMode = "none"
                FullMode.Text = "Full"
            End If
        Catch ex As Exception

        End Try

    End Sub
    'This is for STOP playing
    Private Sub btnStop_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_Stop.Click
        'creating StopPlay() control
        nowPlayling.Visible = False
        trackStatus.Visible = False
        gTrackBar1.Value = 0
        MediaPlayer.URL = ""
        Me.Text = "Minox Player"
        gTrackBar1.Value = 0
        Timer2.Stop()
        maxValue.Text = "00:00"
        minValue.Text = "00:00"
        Timer7.Enabled = False
        Timer5.Enabled = False
        btn_Play.Visible = True
    End Sub

    Private Sub PlayItems_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
    End Sub
    'Delete selected items in Playlist2

    'ClearAll in Playlist2

    'Programming BackgroundColor theme choser for Playlist2
    Private Sub SilverToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        'Silver background color
        Form2.Playlist.BackColor = Color.Silver
    End Sub

    Private Sub BlackToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        'Black background color
        Form2.Playlist.BackColor = Color.Black
    End Sub

    Private Sub GreenToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        'Green background color

        Form2.Playlist.BackColor = Color.Green
    End Sub

    Private Sub BlueToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        'Blue background color

        Form2.Playlist.BackColor = Color.Blue
    End Sub

    Private Sub OrangeToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        'Orange background color

        Form2.Playlist.BackColor = Color.Orange
    End Sub

    Private Sub OrangeRedToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Form2.Playlist.BackColor = Color.OrangeRed
    End Sub
    Private Sub BackColorToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
    End Sub
    'Programming playlist text color theme
    Private Sub OrangeToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Form2.Playlist.ForeColor = Color.Orange
    End Sub

    Private Sub RedToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        'ForeColor of text changed into Red
        Form2.Playlist.ForeColor = Color.Red
    End Sub

    Private Sub WhiteToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        'ForeColor of text changed into White
        Form2.Playlist.ForeColor = Color.White
    End Sub

    Private Sub YellowToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        'ForeColor of text changed into Yellow
        Form2.Playlist.ForeColor = Color.Yellow
    End Sub

    Private Sub BlueToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

        Form2.Playlist.ForeColor = Color.Blue
    End Sub

    Private Sub LightGreenToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

        Form2.Playlist.ForeColor = Color.LightGreen
    End Sub

    Private Sub DodgerBlueToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

        Form2.Playlist.ForeColor = Color.DodgerBlue
    End Sub
    Private Sub btnNext(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_Next.Click
        StopPlay()
        NextTrack()
        Timer5.Enabled = True
        trackStatus.Visible = True
        nowPlayling.Text = System.IO.Path.GetFileName(Form2.Playlist.SelectedItem)
        NotifyIcon1.Visible = True
        NotifyIcon1.ShowBalloonTip(3000, "Now playing:", System.IO.Path.GetFileName(Form2.Playlist.SelectedItem), ToolTipIcon.Info)
    End Sub

    Private Sub btnPrev(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_Prev.Click
        StopPlay()
        PreviousTrack()
        Timer5.Enabled = True
        trackStatus.Visible = True
        nowPlayling.Text = System.IO.Path.GetFileName(Form2.Playlist.SelectedItem)
        NotifyIcon1.Visible = True
        NotifyIcon1.ShowBalloonTip(3000, "Now playing:", System.IO.Path.GetFileName(Form2.Playlist.SelectedItem), ToolTipIcon.Info)
    End Sub

    Private Sub btnAdd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_Add.Click
        'fixed openFilesDialog
        'developer: Amar Tufo
        'source fixes: VB.PLAYER v1.0.0

        Dim ofd As New OpenFileDialog

        ofd.FileName = ""
        ofd.Title = "Load Music"
        ofd.Multiselect = True
        ofd.ShowDialog()
        ofd.Filter = "Mp3 Files (*.mp3) |*.mp3"

        For I As Integer = 0 To ofd.FileNames.Count - 1
            Form2.PlayList1.Items.Add(ofd.FileNames(I))
            Form2.Playlist.Items.Add(ofd.SafeFileNames(I))
            Form2.lblCount.Text = ": " & (Form2.Playlist.Items.Count.ToString)
        Next
        If Form2.PlayList1.Items.Count = 0 = True Then
            MsgBox("You suck '''", MsgBoxStyle.Critical, "ERROR")
        Else
            Form2.PlayList1.SelectedIndex = 0
            Form2.Playlist.SelectedIndex = 0
        End If
    End Sub
    Private Sub RedToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Form2.Playlist.BackColor = Color.Gold
    End Sub

    Private Sub YellowToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Form2.Playlist.BackColor = Color.Yellow
    End Sub

    Private Sub MagentaToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Form2.Playlist.ForeColor = Color.Magenta
    End Sub
    Private Sub BlueToolStripMenuItem2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Play1.BackColor = Color.DodgerBlue
        Prev1.BackColor = Color.DodgerBlue
        Stop1.BackColor = Color.DodgerBlue
        Next1.BackColor = Color.DodgerBlue
    End Sub
    Private Sub SilverToolStripMenuItem1_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Play1.BackColor = Color.Silver
        Prev1.BackColor = Color.Silver
        Stop1.BackColor = Color.Silver
        Next1.BackColor = Color.Silver
    End Sub
    Private Sub DefaultToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        'DefaultMenuStrip______________ ControlStyler
        Play1.BackColor = Color.Black
        Prev1.BackColor = Color.Black
        Stop1.BackColor = Color.Black
        Next1.BackColor = Color.Black
    End Sub

    Private Sub RedToolStripMenuItem2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Play1.BackColor = Color.Red
        Prev1.BackColor = Color.Red
        Stop1.BackColor = Color.Red
        Next1.BackColor = Color.Red
    End Sub

    Private Sub WhiteSmokeToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Play1.BackColor = Color.WhiteSmoke
        Prev1.BackColor = Color.WhiteSmoke
        Stop1.BackColor = Color.WhiteSmoke
        Next1.BackColor = Color.WhiteSmoke
    End Sub

    Private Sub KhakiToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Play1.BackColor = Color.Khaki
        Prev1.BackColor = Color.Khaki
        Stop1.BackColor = Color.Khaki
        Next1.BackColor = Color.Khaki
    End Sub
    Private Sub btnVolume_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_Volume.Click
      
    End Sub

    Private Sub AquaToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Form2.Playlist.ForeColor = Color.Aqua
    End Sub

    Private Sub LimeToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Form2.Playlist.ForeColor = Color.Lime
    End Sub

    Private Sub LimeToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Play1.BackColor = Color.Lime
        Prev1.BackColor = Color.Lime
        Stop1.BackColor = Color.Lime
        Next1.BackColor = Color.Lime
    End Sub

    Private Sub Form1_DragDrop(ByVal sender As Object, ByVal e As System.Windows.Forms.DragEventArgs) Handles Me.DragDrop
        'Multiitems drag & drop function
        If e.Data.GetDataPresent(DataFormats.FileDrop) Then
            Dim draggedFiles As String() = CType(e.Data.GetData(DataFormats.FileDrop), String())
            Dim Files As String() = CType(e.Data.GetData(DataFormats.FileDrop), String())
            For Each filename As String In draggedFiles
                Form2.Playlist.Items.Add(FileIO.FileSystem.GetFileInfo(filename).Name)
                Form2.PlayList1.Items.Add(filename)
                Form2.lblCount.Text = ": " & (Form2.Playlist.Items.Count.ToString)
            Next
            Form2.PlayList1.SelectedIndex = 0
            Form2.Playlist.SelectedIndex = 0
        End If


        'Folder Drag & Drop function
        Dim colFiles() As String = e.Data.GetData(DataFormats.FileDrop, True)
        For i = 0 To colFiles.Count - 1
            Dim list As List(Of String) = Form2.GetAllFiles.GetFileList(colFiles(i))
            For Each path In list
                Form2.Playlist.Items.Add(System.IO.Path.GetFileName(path))
                Form2.PlayList1.Items.Add(path)
            Next '
            Form2.PlayList1.SelectedIndex = 0
            Form2.Playlist.SelectedIndex = 0
        Next

    End Sub

    Private Sub Form1_DragEnter(ByVal sender As Object, ByVal e As System.Windows.Forms.DragEventArgs) Handles Me.DragEnter
        'Playlist drag&drop enter subprogram which alows computer to read the folder on .mp3 files, and play them. . . 
        Form2.lblCount.Text = ": " & (Form2.Playlist.Items.Count.ToString)

     
        If e.Data.GetDataPresent(DataFormats.FileDrop) Then
            e.Effect = DragDropEffects.Copy
        End If
               
        'If e.Data.GetDataPresent(DataFormats.FileDrop) Then
        'e.Effect = DragDropEffects.Copy
        'End If
      
    End Sub

    Private Sub Form1_FormClosed(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosedEventArgs) Handles Me.FormClosed
        My.Settings.myPlaylist = Form2.Playlist.Text.ToString()
        My.Settings.TechThema = "TechThema"
    End Sub
    'Kada se program zatvori, playlista se sama spasi'
    Private Sub Form1_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        'this is fadeOut_Effect
        'declaration date: 2, January 2015
        'develoeper: Amar Tufo, 2015

        'For fadeout = 90 To -10 Step -10
        'Me.Opacity = fadeout / 100
        'Me.Refresh()
        'Threading.Thread.Sleep(100)
        'Next
        '________________________________
        'savePlaylist;
        'function: savePlaylist
        'developer: Amar Tufo
        'verzija funkcije: 2.0
        'GREŠKA OTKLONJENA
        'Subota, 31 August 2013

        'imamo malih problema sa dopustom registracije ekstenzije
        'tako da je ova funkcija playliste još uvijek pod testom;
        'javi mi grešku da ne može da registruje moj tip playliste koji je .minox
        'ukoliko se Minox Player ne pokrene kao administrator
        Dim i As Integer
        Try
            'kreira direktori playlist na disk C
            System.IO.Directory.CreateDirectory("C:\playlist")
            'spašava playlistu u playlist.txt tekstualnu datoteku
            'u prethodno kreiran direktori C:\playlist
            w = New IO.StreamWriter("C:\playlist\playlist.txt")
            For i = 0 To Form2.Playlist.Items.Count - 1
                'Spašava adresu svake pjesme u playlisti sa ekstenzijom
                w.WriteLine(Form2.Playlist.Items.Item(i))
                'spašava originalan naziv pjesme sa ekstenzijom
                w.WriteLine(Form2.PlayList1.Items.Item(i))
            Next
            w.Close()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Form1_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown
        If e.KeyCode = Keys.V Then
            'the V schortcut key open VolumeManager control
           
        End If
        '***************************************************
        If e.KeyCode = Keys.P Then
            'the P schortcut key open Playlist control
            If Form2.Visible = True Then
                Form2.Hide()
            Else
                Form2.Show()
            End If
            '***********************************************
        End If
    End Sub
    Public Sub playMusic()
        'MsgBox("No song")
        'Timer2.Stop() '/in case when there is nothing to play
        '*******************
        'player will not reset the timer's
        'opros My.Computer.Audio.Play(My.Resources.btn_EStart, AudioPlayMode.Background)
        Timer5.Enabled = True
        trackStatus.Visible = True
        nowPlayling.Visible = True
        nowPlayling.Text = System.IO.Path.GetFileName(Form2.Playlist.SelectedItem)
        NotifyIcon1.Visible = True
        NotifyIcon1.ShowBalloonTip(3000, "Now playing:", System.IO.Path.GetFileName(Form2.Playlist.SelectedItem), ToolTipIcon.Info)
        'when minox player start's the track it will change the image into pause;

        'End Region
        Try

            If MediaPlayer.playState = WMPPlayState.wmppsPaused Then
                'else the minox player is paused it will change the image into play

                MediaPlayer.Ctlcontrols.play()

            Else
                StopPlay()

                MediaPlayer.URL = Form2.PlayList1.SelectedItem
            End If

            If Me.Text = System.IO.Path.GetFileName(Form2.PlayList1.SelectedItem) Then
                Timer2.Start()
            Else
                Try

                    'Ako nema pjesama na playlisti program neće zapoćeti produkciju
                    'licenca: AmarTufo
                    'verzija greške: playFunction v1.0.0

                Catch ex As Exception
                    Timer2.Stop()
                    gTrackBar1.Value = 0
                    maxValue.Text = "00:00"
                    minValue.Text = "00:00"
                End Try
            End If
        Catch ex As Exception


        End Try
    End Sub
    Public Sub pauseMusic()
        MediaPlayer.Ctlcontrols.pause()
    End Sub
    Public Sub stopMusic()
        'creating StopPlay() control
        gTrackBar1.Value = 0
        MediaPlayer.URL = ""
        Me.Text = "Minox Player"
        gTrackBar1.Value = 0
        Timer2.Stop()
        maxValue.Text = "00:00"
        minValue.Text = "00:00"
        Timer5.Stop()
        trackStatus.Hide()
        nowPlayling.Hide()
        'Play1.Text = "Play"
    End Sub
    Public Sub previousMusic()
        previousTrack()
        StopPlay()
        Timer5.Enabled = True
        trackStatus.Visible = True
        nowPlayling.Text = System.IO.Path.GetFileName(Form2.Playlist.SelectedItem)
        NotifyIcon1.Visible = True
        NotifyIcon1.ShowBalloonTip(3000, "Now playing:", System.IO.Path.GetFileName(Form2.Playlist.SelectedItem), ToolTipIcon.Info)
    End Sub
    Public Sub nextMusic()
        nextTrack()
        StopPlay()
        Timer5.Enabled = True
        trackStatus.Visible = True
        nowPlayling.Text = System.IO.Path.GetFileName(Form2.Playlist.SelectedItem)
        NotifyIcon1.Visible = True
        NotifyIcon1.ShowBalloonTip(3000, "Now playing:", System.IO.Path.GetFileName(Form2.Playlist.SelectedItem), ToolTipIcon.Info)
    End Sub
   
    Private Sub Form1_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        
        'Highly experimental
        'this is extension for Minox Player playlist in order to load .MP3 file with in Minox Player
        'it's require Admin access for aprovall the extension and file types
        If (Not System.IO.Directory.Exists("C:\playlist")) Then
            System.IO.Directory.CreateDirectory("C:\playlist")
            'sada kreiraj file sa ovom lokacijom C:\Program Files\Minox Player\Minox Player\playlist.txt
            If (Not System.IO.File.Exists("C:\playlist\playlist.txt")) Then
                System.IO.File.Create("C:\playlist\playlist.txt")
            End If
        End If

        'My.Computer.Registry.ClassesRoot.CreateSubKey(".mp3").SetValue("", "Minox Player", Microsoft.Win32.RegistryValueKind.String)
        'My.Computer.Registry.ClassesRoot.CreateSubKey("Minox Player\shell\open\command").SetValue("", Application.ExecutablePath & " ""%1"" ", Microsoft.Win32.RegistryValueKind.String)
        'My.Computer.Registry.ClassesRoot.CreateSubKey("Minox Player\DefaultIcon").SetValue("", Application.StartupPath & "\MP3.ico")
        'making the playlist loader extension and icon type
        'My.Computer.Registry.ClassesRoot.CreateSubKey(".minox").SetValue("", "minoxfile", Microsoft.Win32.RegistryValueKind.String)
        'My.Computer.Registry.ClassesRoot.CreateSubKey("minoxfile\shell\open\" & "command").SetValue("", Application.ExecutablePath & " %1", Microsoft.Win32.RegistryValueKind.String)
        'My.Computer.Registry.ClassesRoot.CreateSubKey("minoxfile\DefaultIcon").SetValue("", Application.ExecutablePath)
        'Dim arguments As String = Command()
        'If arguments = String.Empty Then
        'log.Text += "No dropped file found."
        ' Else
        'Dim tempstr As String = arguments.Replace("""", "")
        'Dim SR As New System.IO.StreamReader(tempstr)
        'Try
        'Form2.Playlist.Text += SR.ReadToEnd
        'Form2.PlayList1.Text += SR.ReadToEnd
        'SR.Close()
        'Catch ex As Exception
        'Form2.Playlist.Text += ex.ToString
        'Form2.PlayList1.Text += ex.ToString
        'End Try
        'End If
        'loadPlaylist;
        'function: loadPlaylist upon program startup;
        'developer: Amar Tufo 
        'GREŠKA OTKLONJENA
        'Subota, 31 August 2013
        '*************************************************
        'ućitava Playlistu iz datoteke playlist.txt e
        ' i stora je u glavnoj playlisti sa ekstenzijom datoteka .mp3
        r = New IO.StreamReader("C:\playlist\playlist.txt")
        Try
            While (r.Peek() > -1)
                'initijalizuje Čitać tekstualne datoteke playlist.txt
                'učitava adrese datoteka koje se sviraju
                'npr: C:\Music\Track1.mp3
                Form2.Playlist.Items.Add(r.ReadLine)
                'prikazuje originalne datoteke sa ekstenzijom
                Form2.PlayList1.Items.Add(r.ReadLine)
                'prikazuje trenutan broj datoteka
                'koristi increment metodu i++ umjesto i = i+1
                Form2.lblCount.Text = ": " & (Form2.Playlist.Items.Count.ToString)
                Try
                    'onLoad prevent play
                    StopPlay()
                    'Obnova indeksa selekcije 
                    Form2.Playlist.SelectedIndex = 0
                    'sprećava automatsko reprodukovanje
                Catch ex As Exception 'sprećava grešku da se pojavi u funkciji
                End Try
            End While
            r.Close()
        Catch ex As Exception

        End Try
        'files = FileIO.FileSystem.GetFiles(My.Computer.FileSystem.SpecialDirectories.Desktop, FileIO.SearchOption.SearchAllSubDirectories, "*.mp3")
        'For Each a As String In files
        'Form2.Playlist.Items.Add(FileIO.FileSystem.GetName(a))
        'Next
        'MediaPlayer.URL = files(0)
        'Timer5.Start()
        'nowPlayling.Visible = True
        'nowPlayling.Text = System.IO.Path.GetFileName(Form2.Playlist.SelectedItem)
        '************************************************
        Form2.Playlist.ForeColor = Color.Lime
        'loading CrystalFont As DefaultFont of MinoxPlayer
        Styler.BackgroundImageLayout = ImageLayout.Stretch
        'loading default thema: ---> silverThema;
        technoBlue()
        technologyBlue.Image = My.Resources.CHECK
        'loading CrystalFont As DefaultFont of MinoxPlayer
        minoxLogo.Font = CustomFont.GetInstance(12, FontStyle.Bold)
        minValue.Font = CustomFont.GetInstance(15, FontStyle.Bold)
        maxValue.Font = CustomFont.GetInstance(15, FontStyle.Bold)
        nowPlayling.Font = CustomFont.GetInstance(10, FontStyle.Regular)
        exitProgram.Font = CustomFont.GetInstance(17, FontStyle.Bold)
        minimizeProgram.Font = CustomFont.GetInstance(20, FontStyle.Bold)
        trackStatus.Font = CustomFont.GetInstance(12, FontStyle.Bold)
        nowPlayling.Font = CustomFont.GetInstance(11, FontStyle.Bold)
        volumeCounter.Font = CustomFont.GetInstance(11, FontStyle.Bold)
        volumeCounter.ForeColor = Color.White
        '**********************************************
        'setting and loading splashScreen
        '=============================================================
        'mySplashScreen() 

        Me.Visible = False

        Dim s = New startupScreen

        s.Show()
        'Do processing here or thread.sleep to illustrate the concept
        System.Threading.Thread.Sleep(5000)

        s.Close()

        Me.Visible = True
        '**********************************************
        Timer5.Enabled = False
        trackStatus.Visible = False
        Timer2.Stop()
        Timer2.Enabled = False
        '************************************************
        Me.ShowInTaskbar = False
        Form2.ShowInTaskbar = False
        Form3.ShowInTaskbar = False
        About.ShowInTaskbar = False

        '******************************
        ' OVDE DODATI KOD ZA EXTENZIJU'
        ' MinoxPlayer v2.3.0.3'
        '*******************************************

        MediaPlayer.settings.volume = "50"
        volumeCounter.Text = myVolumeBar.Value
        'TrackBar1.Value = 50
        MediaPlayer.uiMode = "none"
    End Sub

    'End Sub
    'this is default thema of Minox Player
    '*****************(1)****************************************
    Public Sub MetalThema()
        minoxHead.BackgroundImage = My.Resources.minoxHead_Metal
        menuPanel.BackgroundImage = My.Resources.minoxMenu_Metal
        Me.BackgroundImage = My.Resources.minoxCover_Metal1
        Me.BackgroundImageLayout = ImageLayout.Stretch
        myVolumePanel.BackgroundImage = My.Resources.minoxVolume_Metal
        Styler.BackgroundImage = My.Resources.minoxStyler_Metal
        Styler.BackgroundImageLayout = ImageLayout.Stretch
        '*************************** setting new cover on playlist
        Form2.playlistHead.BackgroundImage = My.Resources.playlistHead_Metal
        Form2.playlistMenu.BackgroundImage = My.Resources.playlistMenu_Metal
        Form2.lblCount.Image = My.Resources.playlistMenu_Metal
        '*************************** setting new cover on playMode
        Form3.playModeHead.BackgroundImage = My.Resources.playModeHead_Metal
        Form3.BackgroundImage = My.Resources.playModeCover_Metal
    End Sub
    'note: This thema will change the TechBlack thema
    Public Sub CoffeThema()
        minoxHead.BackgroundImage = My.Resources.minoxHead_Coffe
        menuPanel.BackgroundImage = My.Resources.minoxMenu_Caffe
        Me.BackgroundImage = My.Resources.minoxCover_Caffe
        Me.BackgroundImageLayout = ImageLayout.Stretch
        myVolumePanel.BackgroundImage = My.Resources.volumeCover_Caffe
        Styler.BackgroundImage = My.Resources.minoxStyler_Caffe
        Styler.BackgroundImageLayout = ImageLayout.Stretch
        '*************************** setting new cover on playlist
        Form2.playlistHead.BackgroundImage = My.Resources.playlistHead_Caffe
        Form2.playlistMenu.BackgroundImage = My.Resources.playlistMenu_Coffe
        Form2.lblCount.Image = My.Resources.playlistMenu_Coffe
        '*************************** setting new cover on playMode
        Form3.playModeHead.BackgroundImage = My.Resources.playModeHead_Coffe
        Form3.BackgroundImage = My.Resources.playModeCover_Coffe
        'adding controls skins
        btn_Play.Image = My.Resources.playback_play_icon_48
        btn_Pause.Image = My.Resources.blackPause
        btn_Stop.Image = My.Resources.blackStop
        btn_Next.Image = My.Resources.blackNext
        btn_Prev.Image = My.Resources.blackPrevious
    End Sub
    '*** now setting up LightPink thema ********************************
    '*********************(2)*******************************************
    Public Sub PinkTheme()
        minoxHead.BackgroundImage = My.Resources.minoxHead_Pink
        menuPanel.BackgroundImage = My.Resources.minoxBody_Pink
        Me.BackgroundImage = My.Resources.minoxCover_Pink
        myVolumePanel.BackgroundImage = My.Resources.volumeCover_Pink
        Styler.BackgroundImage = My.Resources.stylerBody_Pink
        Styler.BackgroundImageLayout = ImageLayout.Stretch
        '*************************** setting new cover on playlist
        Form2.playlistHead.BackgroundImage = My.Resources.playHead_Pink        'nedostaje
        Form2.playlistMenu.BackgroundImage = My.Resources.playlistMenuBody_Pink
        Form2.lblCount.Image = My.Resources.playlistMenuBody_Pink
        '*************************** setting new cover on playMode
        Form3.playModeHead.BackgroundImage = My.Resources.playModeCover_Pink
        Form3.BackgroundImage = My.Resources.playModeCover_Pink
    End Sub
    '*******************>> Orange Thema <<*******************************
    '*************************(3)****************************************
    Public Sub OrangeTheme()
        minoxHead.BackgroundImage = My.Resources.minoxHead_Orange
        menuPanel.BackgroundImage = My.Resources.minoxBody_Orange
        Me.BackgroundImage = My.Resources.minoxCover_Orange
        myVolumePanel.BackgroundImage = My.Resources.volumeCover_Orange1
        Styler.BackgroundImage = My.Resources.stylerBody_Orange
        Styler.BackgroundImageLayout = ImageLayout.Stretch
        '*************************** setting new cover on playlist
        Form2.playlistHead.BackgroundImage = My.Resources.playlistHead_Orange        'nedostaje
        Form2.playlistMenu.BackgroundImage = My.Resources.playlistMenuBody_Orange
        Form2.lblCount.Image = My.Resources.playlistMenuBody_Orange
        '*************************** setting new cover on playMode
        Form3.playModeHead.BackgroundImage = My.Resources.playModeCover_Orange
        Form3.BackgroundImage = My.Resources.playModeCover_Orange

    End Sub
    '*******************>> Black Thema <<******************************
    '**************************(4)*************************************
    Public Sub BlackGloos()
        minoxHead.BackgroundImage = My.Resources.minoxHeadTech_Black
        menuPanel.BackgroundImage = My.Resources.minoxMenuTech_Black
        Me.BackgroundImage = My.Resources.minoxCoverTech_Black
        myVolumePanel.BackgroundImage = My.Resources.volumeCoverTech_Black
        Styler.BackgroundImage = My.Resources.minoxStylerTech_Black
        Styler.BackgroundImageLayout = ImageLayout.Stretch
        '*************************** setting new cover on playlist
        Form2.playlistHead.BackgroundImage = My.Resources.playlistHeadTech_Black       'nedostaje
        Form2.playlistMenu.BackgroundImage = My.Resources.playlistMenuTech_Black
        Form2.lblCount.Image = My.Resources.playlistMenuTech_Black
        '*************************** setting new cover on playMode
        Form3.playModeHead.BackgroundImage = My.Resources.playModeHeadTech_Black
        Form3.BackgroundImage = My.Resources.playModeCoverTech_Black
    End Sub
    '********************>> Brown Thema <<****************************
    '***************************(5)***********************************
    Public Sub BrownGloss()
        minoxHead.BackgroundImage = My.Resources.minoxHead_Brown
        menuPanel.BackgroundImage = My.Resources.minoxBody_Brown
        Me.BackgroundImage = My.Resources.minoxCover_Brown
        myVolumePanel.BackgroundImage = My.Resources.volumeCover_Brown
        Styler.BackgroundImage = My.Resources.stylerBody_Brown
        Styler.BackgroundImageLayout = ImageLayout.Stretch
        '*************************** setting new cover on playlist
        Form2.playlistHead.BackgroundImage = My.Resources.playlistHead_Brown       'nedostaje
        Form2.playlistMenu.BackgroundImage = My.Resources.playlistMenuBody_Brown
        Form2.lblCount.Image = My.Resources.playlistMenuBody_Brown
        '*************************** setting new cover on playMode
        Form3.playModeHead.BackgroundImage = My.Resources.playModeHead_Brown
        Form3.BackgroundImage = My.Resources.playModeCover_Brown
    End Sub
    '**********************>> Green Thema <<****************************
    '*****************************(6)***********************************
    Public Sub GlossGreen()
        minoxHead.BackgroundImage = My.Resources.minoxHead_Green
        menuPanel.BackgroundImage = My.Resources.minoxBody_Green
        Me.BackgroundImage = My.Resources.minoxCover_Green
        myVolumePanel.BackgroundImage = My.Resources.volumeCover_Green
        Styler.BackgroundImage = My.Resources.stylerBody_Green
        Styler.BackgroundImageLayout = ImageLayout.Stretch
        '*************************** setting new cover on playlist
        Form2.playlistHead.BackgroundImage = My.Resources.playlistHead_Green      'nedostaje
        Form2.playlistMenu.BackgroundImage = My.Resources.playlistMenuBody_Green
        Form2.lblCount.Image = My.Resources.playlistMenuBody_Green
        '*************************** setting new cover on playMode
        Form3.playModeHead.BackgroundImage = My.Resources.playModeHead_Green
        Form3.BackgroundImage = My.Resources.playModeCover_Green
    End Sub
    '*********************>> Blue Thema <<*********************************
    '***************************(7)****************************************
    Public Sub LightBlue()
        minoxHead.BackgroundImage = My.Resources.minoxHead_Blue
        menuPanel.BackgroundImage = My.Resources.minoxBody_Blue
        Me.BackgroundImage = My.Resources.minoxCover_Blue
        myVolumePanel.BackgroundImage = My.Resources.volumeCover_Blue
        Styler.BackgroundImage = My.Resources.stylerBody_Blue
        Styler.BackgroundImageLayout = ImageLayout.Stretch
        '*************************** setting new cover on playlist
        Form2.playlistHead.BackgroundImage = My.Resources.playlistHead_Blue        'nedostaje
        Form2.playlistMenu.BackgroundImage = My.Resources.playlistMenuBody_Blue
        Form2.lblCount.Image = My.Resources.playlistMenuBody_Blue
        '*************************** setting new cover on playMode
        Form3.playModeHead.BackgroundImage = My.Resources.playModeHead_Blue
        Form3.BackgroundImage = My.Resources.playModeCover_Blue
    End Sub
    '*********************** >>TechnoBlue Thema<<**************************
    '*********************************(8)**********************************
    Public Sub technoBlue()
        minoxHead.BackgroundImage = My.Resources.minoxHeadBlue_Tech
        menuPanel.BackgroundImage = My.Resources.minoxMenuBlue_Tech
        Me.BackgroundImage = My.Resources.minoxCoverBlue_Tech
        myVolumePanel.BackgroundImage = My.Resources.volumeCoverBlue_Tech
        Styler.BackgroundImage = My.Resources.minoxStylerBlue_Tech
        Styler.BackgroundImageLayout = ImageLayout.Stretch
        '*************************** setting new cover on playlist
        Form2.playlistHead.BackgroundImage = My.Resources.playlistHeadBlue_Tech        'nedostaje
        Form2.playlistMenu.BackgroundImage = My.Resources.playlistMenuBlue_Tech
        Form2.lblCount.Image = My.Resources.playlistMenuBlue_Tech
        '*************************** setting new cover on playMode
        Form3.playModeHead.BackgroundImage = My.Resources.playModeHeadBlue_Tech
        Form3.BackgroundImage = My.Resources.playModeCoverBlue_Tech
    End Sub
    Public Sub darkGrayThema()
        minoxHead.BackgroundImage = My.Resources.minoxHeadLight_Gray
        menuPanel.BackgroundImage = My.Resources.minoxMenuLight_Gray
        Me.BackgroundImage = My.Resources.minoxCoverLight_Gray
        myVolumePanel.BackgroundImage = My.Resources.volumeCoverLight_Gray
        Styler.BackgroundImage = My.Resources.minoxStylerLight_Gray
        Styler.BackgroundImageLayout = ImageLayout.Stretch
        '*************************** setting new cover on playlist
        Form2.playlistHead.BackgroundImage = My.Resources.playlistHeadLight_Gray      'nedostaje
        Form2.playlistMenu.BackgroundImage = My.Resources.playlistMenuLight_Gray
        Form2.lblCount.Image = My.Resources.playlistMenuLight_Gray
        '*************************** setting new cover on playMode
        Form3.playModeHead.BackgroundImage = My.Resources.playModeHeadLight_Gray
        Form3.BackgroundImage = My.Resources.playModeCoverLight_Gray
    End Sub
    Public Sub techOrangeThema()
        minoxHead.BackgroundImage = My.Resources.minoxHeadOrange_Tech
        menuPanel.BackgroundImage = My.Resources.minoxMenuOrange_Tech
        Me.BackgroundImage = My.Resources.minoxCoverOrange_Tech
        myVolumePanel.BackgroundImage = My.Resources.volumeCoverOrange_Tech
        Styler.BackgroundImage = My.Resources.minoxStylerOrange_Tech
        Styler.BackgroundImageLayout = ImageLayout.Stretch
        '*************************** setting new cover on playlist
        Form2.playlistHead.BackgroundImage = My.Resources.playlistHeadOrange_Tech      'nedostaje
        Form2.playlistMenu.BackgroundImage = My.Resources.playlistMenuOrange_Tech
        Form2.lblCount.Image = My.Resources.playlistMenuOrange_Tech
        '*************************** setting new cover on playMode
        Form3.playModeHead.BackgroundImage = My.Resources.playModeHeadOrange_Tech
        Form3.BackgroundImage = My.Resources.playModeCoverOrange_Tech
    End Sub
    Public Sub coolPurpleThema()
        minoxHead.BackgroundImage = My.Resources.minoxHead_Purple
        menuPanel.BackgroundImage = My.Resources.minoxMenu_Purple
        Me.BackgroundImage = My.Resources.minoxCover_Purple
        myVolumePanel.BackgroundImage = My.Resources.volumeCover_Purple
        Styler.BackgroundImage = My.Resources.minoxStyler_Purple
        Styler.BackgroundImageLayout = ImageLayout.Stretch
        '*************************** setting new cover on playlist
        Form2.playlistHead.BackgroundImage = My.Resources.playlistHead_Purple      'nedostaje
        Form2.playlistMenu.BackgroundImage = My.Resources.playlistMenu_Purple
        Form2.lblCount.Image = My.Resources.playlistMenu_Purple
        '*************************** setting new cover on playMode
        Form3.playModeHead.BackgroundImage = My.Resources.playModeHead_Purple
        Form3.BackgroundImage = My.Resources.playModeCover_Purple
    End Sub
    'greenLime_Thema code goes here
    Public Sub greenLime_Thema()
        minoxHead.BackgroundImage = My.Resources.minoxHead_LIME
        menuPanel.BackgroundImage = My.Resources.minoxBody_LIME
        Me.BackgroundImage = My.Resources.minoxCover_LIME
        myVolumePanel.BackgroundImage = My.Resources.volumeCover_LIME
        Styler.BackgroundImage = My.Resources.stylerBody_LIME
        Styler.BackgroundImageLayout = ImageLayout.Stretch
        '*************************** setting new cover on playlist
        Form2.playlistHead.BackgroundImage = My.Resources.playlistBody_LIME  'nedostaje
        Form2.playlistMenu.BackgroundImage = My.Resources.playlistMenuBody_LIME
        Form2.lblCount.Image = My.Resources.playlistMenuBody_LIME
        '*************************** setting new cover on playMode
        Form3.playModeHead.BackgroundImage = My.Resources.playModeBody_LIME
        Form3.BackgroundImage = My.Resources.playModeCover_LIME
    End Sub
    Private Sub Form1_Resize(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Resize
        Dim f As Form = sender
        If f.WindowState = FormWindowState.Minimized Then
            Me.Hide()
            NotifyIcon1.ShowBalloonTip(3000, "Minox Player", "Minox Player went to system tray mode", ToolTipIcon.Warning)
            NotifyIcon1.Visible = True
        End If
    End Sub

    Private Sub NotifyIcon1_MouseDoubleClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles NotifyIcon1.MouseDoubleClick
        Me.Show()
        Me.WindowState = FormWindowState.Normal
        NotifyIcon1.Visible = False

    End Sub

    Private Sub ExitToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

        Application.Exit()
    End Sub
    Private Sub AboutUsToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Form2.Show()
    End Sub

    Private Sub VToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        System.Diagnostics.Process.Start("http://www.minoxmp3player.blogspot.com")
    End Sub

    Private Sub JoinUsMinoxTMToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        System.Diagnostics.Process.Start("http://www.facebook.com/MinoxPlayer")
    End Sub

    Private Sub TextBox1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Txt_TrackName.Click
        '   Me.Track.Items.Add(1)
    End Sub

    Private Sub Timer2_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer2.Tick
        Try
            'time track duration
            minValue.Text = MediaPlayer.Ctlcontrols.currentPositionString
            maxValue.Text = MediaPlayer.currentMedia.durationString
            'this is trackbar component
            'trackBarSeekBar.Maximum = MediaPlayer.currentMedia.duration
            'trackBarSeekBar.Value = MediaPlayer.Ctlcontrols.currentPosition
            gTrackBar1.MaxValue = MediaPlayer.currentMedia.duration
            gTrackBar1.Value = MediaPlayer.Ctlcontrols.currentPosition
        Catch ex As Exception
        End Try
    End Sub

    Private Sub CLOSEToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Form2.Close()
    End Sub
    'setting light effect on main controls
    'setting previousTrack white efect
    'effect is enabled using mouseEnter & mouseLeave method
    Private Sub btn_Prev_MouseEnter(ByVal sender As Object, ByVal e As System.EventArgs) Handles btn_Prev.MouseEnter
        btn_Prev.Image = My.Resources.whitePrevious
    End Sub

    Private Sub btn_Prev_MouseLeave(ByVal sender As Object, ByVal e As System.EventArgs) Handles btn_Prev.MouseLeave
        btn_Prev.Image = My.Resources.blackPrevious
    End Sub

    Private Sub btn_Pause_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_Pause.Click
        Timer7.Enabled = True
        Timer5.Stop()
        MediaPlayer.Ctlcontrols.pause()

    End Sub

    Private Sub btn_Pause_MouseEnter(ByVal sender As Object, ByVal e As System.EventArgs) Handles btn_Pause.MouseEnter
        btn_Pause.Image = My.Resources.whitePause
    End Sub


    Private Sub btn_Pause_MouseLeave(ByVal sender As Object, ByVal e As System.EventArgs) Handles btn_Pause.MouseLeave
        btn_Pause.Image = My.Resources.blackPause
    End Sub

    Private Sub btn_Play_MouseEnter(ByVal sender As Object, ByVal e As System.EventArgs) Handles btn_Play.MouseEnter
        'My.Computer.Audio.Play(My.Resources.btnClick, AudioPlayMode.Background)
        btn_Play.Image = My.Resources.playBijela
    End Sub

    Private Sub btn_Play_MouseLeave(ByVal sender As Object, ByVal e As System.EventArgs) Handles btn_Play.MouseLeave
        btn_Play.Image = My.Resources.playback_play_icon_48
    End Sub

    Private Sub btn_Stop_MouseEnter(ByVal sender As Object, ByVal e As System.EventArgs) Handles btn_Stop.MouseEnter
        btn_Stop.Image = My.Resources.whiteStop
    End Sub

    Private Sub btn_Stop_MouseLeave(ByVal sender As Object, ByVal e As System.EventArgs) Handles btn_Stop.MouseLeave
        btn_Stop.Image = My.Resources.blackStop
    End Sub

    Private Sub btn_Add_MouseEnter(ByVal sender As Object, ByVal e As System.EventArgs) Handles btn_Add.MouseEnter
        'btn_Add.Image = My.Resources.whiteEject
    End Sub

    Private Sub btn_Add_MouseLeave(ByVal sender As Object, ByVal e As System.EventArgs) Handles btn_Add.MouseLeave
        'btn_Add.Image = My.Resources.blackImport
    End Sub
    '**********************

    Private Sub btn_Next_MouseEnter(ByVal sender As Object, ByVal e As System.EventArgs) Handles btn_Next.MouseEnter
        btn_Next.Image = My.Resources.whiteNext
    End Sub

    Private Sub btn_Next_MouseLeave(ByVal sender As Object, ByVal e As System.EventArgs) Handles btn_Next.MouseLeave
        btn_Next.Image = My.Resources.blackNext
    End Sub

    Private Sub btn_Volume_MouseEnter(ByVal sender As Object, ByVal e As System.EventArgs) Handles btn_Volume.MouseEnter
        btn_Volume.Image = My.Resources.whiteVolume
    End Sub

    Private Sub btn_Volume_MouseLeave(ByVal sender As Object, ByVal e As System.EventArgs) Handles btn_Volume.MouseLeave
        btn_Volume.Image = My.Resources.blackVolume
    End Sub
    'TEST
    Private Sub ClearToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Try
            Form2.Playlist.Items.Clear()
            Form2.PlayList1.Items.Clear()
            Form2.lblCount.Text = ": " & (Form2.Playlist.Items.Count.ToString)

        Catch ex As Exception

        End Try

    End Sub

    Private Sub DeleteToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Try
            Form2.Playlist.Items.Remove(Form2.Playlist.SelectedItem)
            Form2.PlayList1.Items.Remove(Form2.PlayList1.SelectedItem)
            Form2.lblCount.Text = ": " & (Form2.Playlist.Items.Count.ToString)
        Catch ex As Exception

        End Try

    End Sub

    Private Sub SaveToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        MsgBox("saveItems:- this method is not yet implemented", MsgBoxStyle.Information)

    End Sub

    Private Sub LoadToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        MsgBox("loadItems:- this method is not yet implemented", MsgBoxStyle.Information)
    End Sub

    Private Sub TrackList_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs)
        Me.Text = Form2.Playlist.SelectedItem
    End Sub

    Private Sub PlaylistToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PlaylistToolStripMenuItem.Click
        Try
            If Form2.Visible = True Then
                Form2.Hide()
            Else
                Form2.Show()
            End If
        Catch ex As Exception
        End Try
    End Sub


    Private Sub btn_PlayList_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_PlayList.Click
        If Form2.Visible = True Then
            Form2.Hide()
        Else
            Form2.Show()
        End If
    End Sub

    Private Sub btn_PlayList_MouseEnter(ByVal sender As Object, ByVal e As System.EventArgs) Handles btn_PlayList.MouseEnter
        btn_PlayList.Image = My.Resources.playListWhite
    End Sub

    Private Sub btn_PlayList_MouseLeave(ByVal sender As Object, ByVal e As System.EventArgs) Handles btn_PlayList.MouseLeave
        btn_PlayList.Image = My.Resources.playListBlack
    End Sub

    Private Sub ImportToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ImportToolStripMenuItem.Click
        'fixed openFilesDialog
        'developer: Amar Tufo
        'source fixes: VB.PLAYER v1.0.0
        'source fixes: Bass Utilities Test
        'fixed on 3, January 2015 (C) Amar Tufo
        Dim ofd As New OpenFileDialog
        ofd.FileName = Nothing
        ofd.Title = "Load Music"
        ofd.Filter = "Song File(*.mp3;*.wav)|*.mp3;*.wav|All File(*.*)|*.*"
        ofd.Multiselect = True
        ofd.ShowDialog()
        'Nedostaje enumerator Playliste
        'On bi trebao da nabraja svaku novu dodanu datoteku
        'Kao npr: "1.Track1.mp3", "2.Track2.mp3", "3.Track3.mp3" . . . "Track.mp3 +++"
        For I As Integer = 0 To ofd.FileNames.Count - 1
            Form2.PlayList1.Items.Add(ofd.FileNames(I.ToString))
            Form2.Playlist.Items.Add(ofd.SafeFileNames(I.ToString))
            Form2.lblCount.Text = ": " & (Form2.Playlist.Items.Count.ToString)
        Next
        If Form2.PlayList1.Items.Count = 0 = True Then
            MsgBox("You suck '''", MsgBoxStyle.Critical, "ERROR")
        Else
            Form2.PlayList1.SelectedIndex = 0
            Form2.Playlist.SelectedIndex = 0
        End If
    End Sub
    ' =============================================================
    ' msToTime
    Private Sub VolumeSettingsToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub AboutToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AboutToolStripMenuItem.Click
        About.Show()
    End Sub
    
    Private Sub volumeBar_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles volumeBar.ValueChanged
        Try

        Catch ex As Exception

        End Try
    End Sub

    Private Sub gTrackBar1_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles gTrackBar1.MouseDown
        Try
            Timer2.Enabled = False
            Timer2.Stop()
            Timer2.Enabled = True
        Catch ex As Exception

        End Try

    End Sub


    Private Sub gTrackBar1_MouseUp(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles gTrackBar1.MouseUp
        Try
            Timer2.Enabled = False
            Timer2.Stop()
            MediaPlayer.Ctlcontrols.currentPosition = gTrackBar1.Value
            Timer2.Enabled = True
            Timer3.Enabled = True
        Catch ex As Exception

        End Try
    End Sub

    'omogućava korisniku da odabere naćin rada Minox Player-a;
    Private Sub PlayModeToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PlayModeToolStripMenuItem.Click
        'Form3.Show()
        'Timer8.Enabled = True
        If Form3.Visible = True Then
            Form3.Hide()
        Else
            Form3.Show()
        End If
    End Sub

    'This part of code is for repeatPlay() function in Playlist
    'It will play continiuosly the items in playlist, all over
    'and over again
    'written by Amar Tufo;
    Private Sub Timer3_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer3.Tick
        MediaPlayer.stretchToFit = True
        If repeatPlay.Checked = True Then
            'MediaPlayer.URL = ""
            Timer3.Enabled = True

        ElseIf MediaPlayer.playState = WMPPlayState.wmppsMediaEnded = True Then
            Form2.Playlist.SelectedIndex = Form2.Playlist.SelectedIndex + 1
            Form2.PlayList1.SelectedIndex = Form2.PlayList1.SelectedIndex + 1
            MediaPlayer.URL = Form2.PlayList1.SelectedItem
        End If

    End Sub
    Private Sub repeatPlay_CheckedChanged_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles repeatPlay.CheckedChanged
        repeatPlay.Checked = True
        If MediaPlayer.playState = WMPPlayState.wmppsMediaEnded Then
            Form2.Playlist.SelectedIndex = Form2.Playlist.SelectedIndex + 1
            Form2.PlayList1.SelectedIndex = Form2.PlayList1.SelectedIndex + 1
            MediaPlayer.URL = Form2.PlayList1.SelectedItem
        ElseIf repeatPlay.Checked = False Then
            MediaPlayer.Ctlcontrols.play()
        End If
    End Sub

    Private Sub Timer4_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer4.Tick
        a = Cursor.Position.X - Me.Location.X
        b = Cursor.Position.Y - Me.Location.Y
    End Sub
    Private Sub PictureBox1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Application.Exit()

    End Sub

    Private Sub PictureBox1_MouseEnter(ByVal sender As Object, ByVal e As System.EventArgs)
        'PictureBox1.BackColor = Color.White
    End Sub

    Private Sub PictureBox1_MouseLeave(ByVal sender As Object, ByVal e As System.EventArgs)
        'PictureBox1.BackColor = Color.White
    End Sub

    Private Sub Label3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles exitProgram.Click
        Application.Exit()
        NotifyIcon1.Visible = False
    End Sub

    Private Sub Label2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles minimizeProgram.Click
        Me.WindowState = FormWindowState.Minimized
        minoxSubMenu.DropDown = Nothing
        NotifyIcon1.Visible = True
        NotifyIcon1.ShowBalloonTip(3000, "Minox Player", "Minox Player went to system tray mode", ToolTipIcon.Warning)
    End Sub

    Private Sub Timer5_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer5.Tick
        Try
            trackStatus.Visible = True
            nowPlayling.Left -= 5

            If nowPlayling.Left <= -Width Then
                nowPlayling.Left = Width

            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub PictureBox1_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PictureBox1.Click
        Try
            If myVolumePanel.Visible = True Then
                myVolumePanel.Hide()
            Else
                myVolumePanel.Show()
            End If
        Catch ex As Exception
        End Try
    End Sub

    Private Sub PictureBox2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub MinimizeToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Me.WindowState = FormWindowState.Minimized
    End Sub

    Private Sub myVolumeBar_Scroll(ByVal sender As Object, ByVal e As System.EventArgs) Handles myVolumeBar.Scroll
        Try
            MediaPlayer.settings.volume = myVolumeBar.Value
            volumeCounter.Text = myVolumeBar.Value
        Catch ex As Exception

        End Try
    End Sub


    Private Sub maxValue_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles maxValue.Click

    End Sub
    'setting mouseHower_Color = Red();
    Private Sub exitProgram_MouseEnter(ByVal sender As Object, ByVal e As System.EventArgs) Handles exitProgram.MouseEnter
        exitProgram.ForeColor = Color.Red
    End Sub
    'setting mouseLeave_Color = White(); which is default
    Private Sub exitProgram_MouseLeave(ByVal sender As Object, ByVal e As System.EventArgs) Handles exitProgram.MouseLeave
        exitProgram.ForeColor = Color.White
    End Sub

    Private Sub minimizeProgram_MouseEnter(ByVal sender As Object, ByVal e As System.EventArgs) Handles minimizeProgram.MouseEnter
        minimizeProgram.ForeColor = Color.Red
    End Sub

    Private Sub minimizeProgram_MouseLeave(ByVal sender As Object, ByVal e As System.EventArgs) Handles minimizeProgram.MouseLeave
        minimizeProgram.ForeColor = Color.White
    End Sub

    Private Sub metalTheme_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles metalTheme.Click
        MetalThema()
        purpleThema.Image = Nothing
        techOrange.Image = Nothing
        'redThema.Image = Nothing
        technologyBlue.Image = Nothing
        darkGray.Image = Nothing
        flatBrown_Thema.Image = Nothing
        greenLime.Image = Nothing
        brownThema.Image = Nothing
        pinkThemes.Image = Nothing
        orangeThema.Image = Nothing
        metalTheme.Image = My.Resources.CHECK
    End Sub

    Private Sub pinkThemes_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles pinkThemes.Click
        PinkTheme()
        purpleThema.Image = Nothing
        techOrange.Image = Nothing
        'redThema.Image = Nothing
        metalTheme.Image = Nothing
        technologyBlue.Image = Nothing
        darkGray.Image = Nothing
        orangeThema.Image = Nothing
        flatBrown_Thema.Image = Nothing
        greenLime.Image = Nothing
        brownThema.Image = Nothing
        pinkThemes.Image = My.Resources.CHECK
    End Sub

    Private Sub orangeThema_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles orangeThema.Click
        OrangeTheme()
        purpleThema.Image = Nothing
        techOrange.Image = Nothing
        metalTheme.Image = Nothing
        technologyBlue.Image = Nothing
        darkGray.Image = Nothing
        pinkThemes.Image = Nothing
        brownThema.Image = Nothing
        flatBrown_Thema.Image = Nothing
        greenLime.Image = Nothing
        orangeThema.Image = My.Resources.CHECK
    End Sub
    Private Sub blackThema_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        CoffeThema()
        purpleThema.Image = Nothing
        techOrange.Image = Nothing
        metalTheme.Image = Nothing
        pinkThemes.Image = Nothing
        brownThema.Image = Nothing
        flatBrown_Thema.Image = Nothing
        greenLime.Image = Nothing
        orangeThema.Image = Nothing
        technologyBlue.Image = Nothing
        darkGray.Image = Nothing
    End Sub

    Private Sub greenThema_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        GlossGreen()
        purpleThema.Image = Nothing
        techOrange.Image = Nothing
        metalTheme.Image = Nothing
        technologyBlue.Image = Nothing
        darkGray.Image = Nothing
        pinkThemes.Image = Nothing
        brownThema.Image = Nothing
        flatBrown_Thema.Image = Nothing
        greenLime.Image = Nothing
    End Sub

    Private Sub brownThema_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles brownThema.Click
        BrownGloss()
        purpleThema.Image = Nothing
        techOrange.Image = Nothing
        technologyBlue.Image = Nothing
        darkGray.Image = Nothing
        metalTheme.Image = Nothing
        pinkThemes.Image = Nothing
        flatBrown_Thema.Image = Nothing
        greenLime.Image = Nothing
        orangeThema.Image = Nothing
        brownThema.Image = My.Resources.CHECK
    End Sub

    Private Sub ExitToolStripMenuItem_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles exitApp.Click
        Application.Exit()
        NotifyIcon1.Visible = False
    End Sub

    Private Sub aboutMinoxPlayer_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles aboutMinoxPlayer.Click
        About.Show()
    End Sub

    Private Sub OurOfficialBlogToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ourBlog.Click
        System.Diagnostics.Process.Start("http://www.minoxmp3player.blogspot.com")
    End Sub

    Private Sub ourFacebook_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ourFacebook.Click
        System.Diagnostics.Process.Start("http://www.facebook.com/MinoxPlayer")
    End Sub

    Private Sub gnu_Play_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles gnu_Play.Click
        playMusic()
    End Sub

    Private Sub gnu_Pause_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles gnu_Pause.Click
        pauseMusic()
    End Sub

    Private Sub gnu_Stop_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles gnu_Stop.Click
        stopMusic()
    End Sub

    Private Sub gnu_Next_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles gnu_Next.Click
        nextMusic()
    End Sub

    Private Sub gnu_Previous_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles gnu_Previous.Click
        previousMusic()
    End Sub

    Private Sub addMusic_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles addMusic.Click
        'fixed openFilesDialog
        'developer: Amar Tufo
        'source fixes: VB.PLAYER v1.0.0
        'source fixes: Bass Utilities Test
        'fixed on 3, January 2015 (C) Amar Tufo
        Dim ofd As New OpenFileDialog
        ofd.FileName = Nothing
        ofd.Title = "Load Music"
        ofd.Filter = "Song File(*.mp3;*.wav)|*.mp3;*.wav|All File(*.*)|*.*"
        ofd.Multiselect = True
        ofd.ShowDialog()
        'Nedostaje enumerator Playliste
        'On bi trebao da nabraja svaku novu dodanu datoteku
        'Kao npr: "1.Track1.mp3", "2.Track2.mp3", "3.Track3.mp3" . . . "Track.mp3 +++"
        For I As Integer = 0 To ofd.FileNames.Count - 1
            Form2.PlayList1.Items.Add(ofd.FileNames(I.ToString))
            Form2.Playlist.Items.Add(ofd.SafeFileNames(I.ToString))
            Form2.lblCount.Text = ": " & (Form2.Playlist.Items.Count.ToString)
        Next
        If Form2.PlayList1.Items.Count = 0 = True Then
            MsgBox("You suck '''", MsgBoxStyle.Critical, "ERROR")
        Else
            Form2.PlayList1.SelectedIndex = 0
            Form2.Playlist.SelectedIndex = 0
        End If
    End Sub

    Private Sub BlackToolStripMenuItem_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BlackToolStripMenuItem.Click
        Form2.Playlist.BackColor = Color.Black
    End Sub

    Private Sub DodgerBlueToolStripMenuItem_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DodgerBlueToolStripMenuItem.Click
        Form2.Playlist.BackColor = Color.DodgerBlue
    End Sub

    Private Sub WhiteToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles WhiteToolStripMenuItem1.Click
        Form2.Playlist.BackColor = Color.White
    End Sub

    Private Sub WhiteToolStripMenuItem_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles WhiteToolStripMenuItem.Click
        Form2.Playlist.ForeColor = Color.White
    End Sub

    Private Sub RedToolStripMenuItem_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RedToolStripMenuItem.Click
        Form2.Playlist.ForeColor = Color.Red
    End Sub

    Private Sub DodgerBlueToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DodgerBlueToolStripMenuItem1.Click
        Form2.Playlist.ForeColor = Color.DodgerBlue
    End Sub

    Private Sub BlackToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BlackToolStripMenuItem1.Click
        Form2.Playlist.ForeColor = Color.Black
    End Sub

    Private Sub LimeToolStripMenuItem_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LimeToolStripMenuItem.Click
        Form2.Playlist.ForeColor = Color.Lime
    End Sub

    Private Sub darkMinoxThema_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub minoxHead_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles minoxHead.MouseDown
        msdwn = True
    End Sub
    Private Sub minoxHead_MouseMove(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles minoxHead.MouseMove
        If msdwn = True Then
            Me.Left = Cursor.Position.X - a
            Me.Top = Cursor.Position.Y - b
        End If
    End Sub

    Private Sub minoxHead_MouseUp(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles minoxHead.MouseUp
        msdwn = False
    End Sub



    Private Sub technologyBlue_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles technologyBlue.Click
        technoBlue()
        blackThemaX.Image = Nothing
        purpleThema.Image = Nothing
        techOrange.Image = Nothing
        darkGray.Image = Nothing
        brownThema.Image = Nothing
        pinkThemes.Image = Nothing
        orangeThema.Image = Nothing
        metalTheme.Image = Nothing
        technologyBlue.Image = My.Resources.CHECK
        flatBrown_Thema.Image = Nothing
        greenLime.Image = Nothing
    End Sub

    Private Sub darkGray_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles darkGray.Click
        darkGrayThema()
        purpleThema.Image = Nothing
        technologyBlue.Image = Nothing
        techOrange.Image = Nothing
        brownThema.Image = Nothing
        blackThemaX.Image = Nothing
        pinkThemes.Image = Nothing
        orangeThema.Image = Nothing
        metalTheme.Image = Nothing
        darkGray.Image = My.Resources.CHECK
        flatBrown_Thema.Image = Nothing
        greenLime.Image = Nothing
    End Sub

    Private Sub techOrange_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles techOrange.Click
        techOrangeThema()
        techOrange.Image = My.Resources.CHECK
        purpleThema.Image = Nothing
        technologyBlue.Image = Nothing
        brownThema.Image = Nothing
        blackThemaX.Image = Nothing
        pinkThemes.Image = Nothing
        orangeThema.Image = Nothing
        metalTheme.Image = Nothing
        darkGray.Image = Nothing
        flatBrown_Thema.Image = Nothing
        greenLime.Image = Nothing
    End Sub

    Private Sub purpleThema_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles purpleThema.Click
        coolPurpleThema()
        purpleThema.Image = My.Resources.CHECK
        darkGray.Image = Nothing
        technologyBlue.Image = Nothing
        techOrange.Image = Nothing
        brownThema.Image = Nothing
        pinkThemes.Image = Nothing
        orangeThema.Image = Nothing
        metalTheme.Image = Nothing
        blackThemaX.Image = Nothing
        flatBrown_Thema.Image = Nothing
        greenLime.Image = Nothing
    End Sub

    Private Sub mnPlaylist_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnPlaylist.Click
        Try
            If Form2.Visible = True Then
                Form2.Hide()
            Else
                Form2.Show()
            End If
        Catch ex As Exception
        End Try
    End Sub

    Private Sub AddFolderToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AddFolderToolStripMenuItem.Click
        MsgBox("This method is not yet declared", MsgBoxStyle.Information)
        'this script is loading folder in playlist
        'Try
        'Form2.Playlist.Items.Clear()
        'Dim folderbrowser As New FolderBrowserDialog
        'If folderbrowser.ShowDialog = Windows.Forms.DialogResult.OK Then
        'Dim folder = New System.IO.DirectoryInfo(folderbrowser.SelectedPath)
        'Form2.Playlist.Items.AddRange(folder.GetFiles)
        'End If

        'Catch ex As Exception
        'Form2.PlayList1.SelectedIndex = 0
        'Form2.Playlist.SelectedIndex = 0
        'End Try
    End Sub

    
    Private Sub registerMinoxPlayer_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        'Try
        'My.Computer.Registry.ClassesRoot.CreateSubKey(".mp3").SetValue("", "Minox Player", Microsoft.Win32.RegistryValueKind.String)
        'My.Computer.Registry.ClassesRoot.CreateSubKey("Minox Player\shell\open\command").SetValue("", Application.ExecutablePath & " ""%1"" ", Microsoft.Win32.RegistryValueKind.String)
        'My.Computer.Registry.ClassesRoot.CreateSubKey("Minox Player\DefaultIcon").SetValue("", Application.StartupPath & "\MP3.ico")
        'Catch ex As Exception

        '        End Try

    End Sub

    Private Sub blackThemaX_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles blackThemaX.Click
        blackThemaX.Image = My.Resources.CHECK
        BlackGloos()
        darkGray.Image = Nothing
        technologyBlue.Image = Nothing
        techOrange.Image = Nothing
        brownThema.Image = Nothing
        pinkThemes.Image = Nothing
        orangeThema.Image = Nothing
        metalTheme.Image = Nothing
        purpleThema.Image = Nothing
        flatBrown_Thema.Image = Nothing
        greenLime.Image = Nothing

    End Sub

    Private Sub FlatStyleToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles flatBrown_Thema.Click
        CoffeThema()
        flatBrown_Thema.Image = My.Resources.CHECK
        blackThemaX.Image = Nothing
        darkGray.Image = Nothing
        technologyBlue.Image = Nothing
        techOrange.Image = Nothing
        brownThema.Image = Nothing
        pinkThemes.Image = Nothing
        orangeThema.Image = Nothing
        metalTheme.Image = Nothing
        purpleThema.Image = Nothing
        greenLime.Image = Nothing
    End Sub

    Private Sub Timer7_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer7.Tick

        If btn_Play.Visible = True Then
            btn_Play.Visible = False
            btn_Play.Image = My.Resources.playBijela
        Else
            btn_Play.Visible = True
        End If
    End Sub

    Private Sub Timer8_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer8.Tick

        '*******************************
        If Form3.Visible = True Then
            For fadein = 0.0 To 1.1 Step 0.1
                Form3.Opacity = fadein
                Form3.Refresh()
                Threading.Thread.Sleep(100)
            Next
        Else
            If Form3.Visible = False Then
                For fadeout = 90 To -10 Step -10
                    Form3.Opacity = fadeout / 100
                    Form3.Refresh()
                    Threading.Thread.Sleep(100)
                Next

            End If
        End If

    End Sub
    'enable and activate greenLimeThema
    Private Sub greenLime_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles greenLime.Click
        greenLime_Thema()
        flatBrown_Thema.Image = My.Resources.CHECK
        blackThemaX.Image = Nothing
        darkGray.Image = Nothing
        technologyBlue.Image = Nothing
        techOrange.Image = Nothing
        brownThema.Image = Nothing
        pinkThemes.Image = Nothing
        orangeThema.Image = Nothing
        metalTheme.Image = Nothing
        purpleThema.Image = Nothing

    End Sub
End Class
