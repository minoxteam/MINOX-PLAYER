﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form2
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form2))
        Me.playlistMenu = New System.Windows.Forms.MenuStrip
        Me.AddToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.LoadToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.SaveToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.DeleteToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem
        Me.ClearToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem
        Me.lblCount = New System.Windows.Forms.Label
        Me.Panel1 = New System.Windows.Forms.Panel
        Me.Playlist = New System.Windows.Forms.ListBox
        Me.PlayList1 = New System.Windows.Forms.ListBox
        Me.playlistHead = New System.Windows.Forms.Panel
        Me.closeApp = New System.Windows.Forms.Label
        Me.minimizeApp = New System.Windows.Forms.Label
        Me.playlistLogo = New System.Windows.Forms.Label
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.playlistMenu.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.playlistHead.SuspendLayout()
        Me.SuspendLayout()
        '
        'playlistMenu
        '
        Me.playlistMenu.BackColor = System.Drawing.Color.Transparent
        Me.playlistMenu.BackgroundImage = Global.Minox_Player.My.Resources.Resources.playlistMenu_Metal
        Me.playlistMenu.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.playlistMenu.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.playlistMenu.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AddToolStripMenuItem, Me.LoadToolStripMenuItem, Me.SaveToolStripMenuItem, Me.DeleteToolStripMenuItem1, Me.ClearToolStripMenuItem1})
        Me.playlistMenu.Location = New System.Drawing.Point(0, 3)
        Me.playlistMenu.Name = "playlistMenu"
        Me.playlistMenu.Size = New System.Drawing.Size(353, 24)
        Me.playlistMenu.TabIndex = 24
        Me.playlistMenu.Text = "MenuStrip2"
        '
        'AddToolStripMenuItem
        '
        Me.AddToolStripMenuItem.BackColor = System.Drawing.Color.Transparent
        Me.AddToolStripMenuItem.ForeColor = System.Drawing.Color.White
        Me.AddToolStripMenuItem.Image = Global.Minox_Player.My.Resources.Resources.plusFiles
        Me.AddToolStripMenuItem.Name = "AddToolStripMenuItem"
        Me.AddToolStripMenuItem.Size = New System.Drawing.Size(57, 20)
        Me.AddToolStripMenuItem.Text = "Add"
        Me.AddToolStripMenuItem.ToolTipText = "Open music files!"
        '
        'LoadToolStripMenuItem
        '
        Me.LoadToolStripMenuItem.BackColor = System.Drawing.Color.Transparent
        Me.LoadToolStripMenuItem.ForeColor = System.Drawing.Color.White
        Me.LoadToolStripMenuItem.Image = Global.Minox_Player.My.Resources.Resources.docPlus
        Me.LoadToolStripMenuItem.Name = "LoadToolStripMenuItem"
        Me.LoadToolStripMenuItem.Size = New System.Drawing.Size(61, 20)
        Me.LoadToolStripMenuItem.Text = "Load"
        Me.LoadToolStripMenuItem.ToolTipText = "Load playlist!"
        '
        'SaveToolStripMenuItem
        '
        Me.SaveToolStripMenuItem.BackColor = System.Drawing.Color.Transparent
        Me.SaveToolStripMenuItem.ForeColor = System.Drawing.Color.White
        Me.SaveToolStripMenuItem.Image = Global.Minox_Player.My.Resources.Resources.saveDoc
        Me.SaveToolStripMenuItem.Name = "SaveToolStripMenuItem"
        Me.SaveToolStripMenuItem.Size = New System.Drawing.Size(59, 20)
        Me.SaveToolStripMenuItem.Text = "Save"
        Me.SaveToolStripMenuItem.ToolTipText = "Save playlist!"
        '
        'DeleteToolStripMenuItem1
        '
        Me.DeleteToolStripMenuItem1.BackColor = System.Drawing.Color.Transparent
        Me.DeleteToolStripMenuItem1.ForeColor = System.Drawing.Color.White
        Me.DeleteToolStripMenuItem1.Image = Global.Minox_Player.My.Resources.Resources.menuDelete
        Me.DeleteToolStripMenuItem1.Name = "DeleteToolStripMenuItem1"
        Me.DeleteToolStripMenuItem1.Size = New System.Drawing.Size(68, 20)
        Me.DeleteToolStripMenuItem1.Text = "Delete"
        Me.DeleteToolStripMenuItem1.ToolTipText = "Delete single track!"
        '
        'ClearToolStripMenuItem1
        '
        Me.ClearToolStripMenuItem1.BackColor = System.Drawing.Color.Transparent
        Me.ClearToolStripMenuItem1.ForeColor = System.Drawing.Color.White
        Me.ClearToolStripMenuItem1.Image = Global.Minox_Player.My.Resources.Resources.menuRefresh
        Me.ClearToolStripMenuItem1.Name = "ClearToolStripMenuItem1"
        Me.ClearToolStripMenuItem1.Size = New System.Drawing.Size(62, 20)
        Me.ClearToolStripMenuItem1.Text = "Clear"
        Me.ClearToolStripMenuItem1.ToolTipText = "Delete all tracks!"
        '
        'lblCount
        '
        Me.lblCount.AutoSize = True
        Me.lblCount.BackColor = System.Drawing.Color.Transparent
        Me.lblCount.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.749999!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCount.ForeColor = System.Drawing.Color.White
        Me.lblCount.Image = Global.Minox_Player.My.Resources.Resources.playlistMenu_Metal1
        Me.lblCount.Location = New System.Drawing.Point(321, 6)
        Me.lblCount.Name = "lblCount"
        Me.lblCount.Size = New System.Drawing.Size(22, 16)
        Me.lblCount.TabIndex = 25
        Me.lblCount.Text = "00"
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.lblCount)
        Me.Panel1.Controls.Add(Me.playlistMenu)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel1.Location = New System.Drawing.Point(0, 435)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(353, 27)
        Me.Panel1.TabIndex = 28
        '
        'Playlist
        '
        Me.Playlist.AllowDrop = True
        Me.Playlist.BackColor = System.Drawing.Color.Black
        Me.Playlist.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.Playlist.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
        Me.Playlist.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.Playlist.ForeColor = System.Drawing.Color.White
        Me.Playlist.FormattingEnabled = True
        Me.Playlist.Location = New System.Drawing.Point(0, 33)
        Me.Playlist.Name = "Playlist"
        Me.Playlist.Size = New System.Drawing.Size(353, 403)
        Me.Playlist.TabIndex = 23
        '
        'PlayList1
        '
        Me.PlayList1.AllowDrop = True
        Me.PlayList1.BackColor = System.Drawing.Color.Maroon
        Me.PlayList1.FormattingEnabled = True
        Me.PlayList1.Location = New System.Drawing.Point(12, 38)
        Me.PlayList1.Name = "PlayList1"
        Me.PlayList1.Size = New System.Drawing.Size(334, 147)
        Me.PlayList1.TabIndex = 26
        '
        'playlistHead
        '
        Me.playlistHead.BackgroundImage = Global.Minox_Player.My.Resources.Resources.playlistHead_Metal
        Me.playlistHead.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.playlistHead.Controls.Add(Me.closeApp)
        Me.playlistHead.Controls.Add(Me.minimizeApp)
        Me.playlistHead.Controls.Add(Me.playlistLogo)
        Me.playlistHead.Dock = System.Windows.Forms.DockStyle.Top
        Me.playlistHead.Location = New System.Drawing.Point(0, 0)
        Me.playlistHead.Name = "playlistHead"
        Me.playlistHead.Size = New System.Drawing.Size(353, 35)
        Me.playlistHead.TabIndex = 29
        '
        'closeApp
        '
        Me.closeApp.AutoSize = True
        Me.closeApp.BackColor = System.Drawing.Color.Transparent
        Me.closeApp.Font = New System.Drawing.Font("Microsoft Sans Serif", 17.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.closeApp.ForeColor = System.Drawing.Color.White
        Me.closeApp.Location = New System.Drawing.Point(328, -1)
        Me.closeApp.Name = "closeApp"
        Me.closeApp.Size = New System.Drawing.Size(20, 32)
        Me.closeApp.TabIndex = 33
        Me.closeApp.Text = "x"
        Me.ToolTip1.SetToolTip(Me.closeApp, "Close Playlist!")
        Me.closeApp.UseCompatibleTextRendering = True
        '
        'minimizeApp
        '
        Me.minimizeApp.AutoSize = True
        Me.minimizeApp.BackColor = System.Drawing.Color.Transparent
        Me.minimizeApp.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.minimizeApp.ForeColor = System.Drawing.Color.White
        Me.minimizeApp.Location = New System.Drawing.Point(3, -2)
        Me.minimizeApp.Name = "minimizeApp"
        Me.minimizeApp.Size = New System.Drawing.Size(19, 37)
        Me.minimizeApp.TabIndex = 32
        Me.minimizeApp.Text = "-"
        Me.minimizeApp.UseCompatibleTextRendering = True
        '
        'playlistLogo
        '
        Me.playlistLogo.AutoSize = True
        Me.playlistLogo.BackColor = System.Drawing.Color.Transparent
        Me.playlistLogo.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.playlistLogo.ForeColor = System.Drawing.Color.White
        Me.playlistLogo.Location = New System.Drawing.Point(132, 5)
        Me.playlistLogo.Name = "playlistLogo"
        Me.playlistLogo.Size = New System.Drawing.Size(61, 24)
        Me.playlistLogo.TabIndex = 31
        Me.playlistLogo.Text = "Playlist"
        Me.playlistLogo.UseCompatibleTextRendering = True
        '
        'Timer1
        '
        Me.Timer1.Enabled = True
        '
        'Form2
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Black
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.ClientSize = New System.Drawing.Size(353, 462)
        Me.Controls.Add(Me.Playlist)
        Me.Controls.Add(Me.playlistHead)
        Me.Controls.Add(Me.PlayList1)
        Me.Controls.Add(Me.Panel1)
        Me.ForeColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Form2"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Text = "Playlist"
        Me.TopMost = True
        Me.playlistMenu.ResumeLayout(False)
        Me.playlistMenu.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.playlistHead.ResumeLayout(False)
        Me.playlistHead.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents playlistMenu As System.Windows.Forms.MenuStrip
    Friend WithEvents LoadToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SaveToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DeleteToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ClearToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents lblCount As System.Windows.Forms.Label
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Playlist As System.Windows.Forms.ListBox
    Friend WithEvents PlayList1 As System.Windows.Forms.ListBox
    Friend WithEvents AddToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents playlistHead As System.Windows.Forms.Panel
    Friend WithEvents playlistLogo As System.Windows.Forms.Label
    Friend WithEvents minimizeApp As System.Windows.Forms.Label
    Friend WithEvents closeApp As System.Windows.Forms.Label
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents ToolTip1 As System.Windows.Forms.ToolTip
End Class
