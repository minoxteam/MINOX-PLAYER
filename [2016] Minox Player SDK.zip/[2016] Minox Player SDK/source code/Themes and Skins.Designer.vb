﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Themes_and_Skins
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Themes_and_Skins))
        Me.trackBarSeekBar = New System.Windows.Forms.TrackBar
        Me.Label1 = New System.Windows.Forms.Label
        Me.menuPanel = New System.Windows.Forms.Panel
        Me.curentTime = New System.Windows.Forms.Label
        Me.maxTime = New System.Windows.Forms.Label
        Me.defaultSkin = New System.Windows.Forms.Button
        Me.silverSkin = New System.Windows.Forms.Button
        Me.blueSkin = New System.Windows.Forms.Button
        Me.redSkin = New System.Windows.Forms.Button
        Me.defaultPreview = New System.Windows.Forms.Button
        Me.grayPreview = New System.Windows.Forms.Button
        Me.redPreview = New System.Windows.Forms.Button
        Me.bluePreview = New System.Windows.Forms.Button
        Me.btn_Stop = New System.Windows.Forms.PictureBox
        Me.btn_Pause = New System.Windows.Forms.PictureBox
        Me.btn_Next = New System.Windows.Forms.PictureBox
        Me.btn_Prev = New System.Windows.Forms.PictureBox
        Me.btn_Play = New System.Windows.Forms.PictureBox
        CType(Me.trackBarSeekBar, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.menuPanel.SuspendLayout()
        CType(Me.btn_Stop, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btn_Pause, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btn_Next, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btn_Prev, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btn_Play, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'trackBarSeekBar
        '
        Me.trackBarSeekBar.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.trackBarSeekBar.Location = New System.Drawing.Point(0, 0)
        Me.trackBarSeekBar.Name = "trackBarSeekBar"
        Me.trackBarSeekBar.Size = New System.Drawing.Size(404, 45)
        Me.trackBarSeekBar.TabIndex = 5
        Me.trackBarSeekBar.TickStyle = System.Windows.Forms.TickStyle.None
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.Label1.Location = New System.Drawing.Point(2, 14)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(46, 15)
        Me.Label1.TabIndex = 6
        Me.Label1.Text = "Default"
        '
        'menuPanel
        '
        Me.menuPanel.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.menuPanel.Controls.Add(Me.curentTime)
        Me.menuPanel.Controls.Add(Me.maxTime)
        Me.menuPanel.Controls.Add(Me.btn_Stop)
        Me.menuPanel.Controls.Add(Me.btn_Pause)
        Me.menuPanel.Controls.Add(Me.btn_Next)
        Me.menuPanel.Controls.Add(Me.btn_Prev)
        Me.menuPanel.Controls.Add(Me.btn_Play)
        Me.menuPanel.Controls.Add(Me.trackBarSeekBar)
        Me.menuPanel.Location = New System.Drawing.Point(2, 40)
        Me.menuPanel.Name = "menuPanel"
        Me.menuPanel.Size = New System.Drawing.Size(405, 68)
        Me.menuPanel.TabIndex = 14
        '
        'curentTime
        '
        Me.curentTime.AutoSize = True
        Me.curentTime.BackColor = System.Drawing.Color.Transparent
        Me.curentTime.ForeColor = System.Drawing.Color.White
        Me.curentTime.Location = New System.Drawing.Point(12, 32)
        Me.curentTime.Name = "curentTime"
        Me.curentTime.Size = New System.Drawing.Size(34, 13)
        Me.curentTime.TabIndex = 16
        Me.curentTime.Text = "00:00"
        '
        'maxTime
        '
        Me.maxTime.AutoSize = True
        Me.maxTime.BackColor = System.Drawing.Color.Transparent
        Me.maxTime.ForeColor = System.Drawing.Color.White
        Me.maxTime.Location = New System.Drawing.Point(362, 32)
        Me.maxTime.Name = "maxTime"
        Me.maxTime.Size = New System.Drawing.Size(34, 13)
        Me.maxTime.TabIndex = 15
        Me.maxTime.Text = "00:00"
        '
        'defaultSkin
        '
        Me.defaultSkin.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.defaultSkin.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.defaultSkin.Location = New System.Drawing.Point(3, 124)
        Me.defaultSkin.Name = "defaultSkin"
        Me.defaultSkin.Size = New System.Drawing.Size(75, 42)
        Me.defaultSkin.TabIndex = 15
        Me.defaultSkin.UseVisualStyleBackColor = False
        '
        'silverSkin
        '
        Me.silverSkin.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.silverSkin.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.silverSkin.Location = New System.Drawing.Point(111, 124)
        Me.silverSkin.Name = "silverSkin"
        Me.silverSkin.Size = New System.Drawing.Size(75, 42)
        Me.silverSkin.TabIndex = 16
        Me.silverSkin.UseVisualStyleBackColor = False
        '
        'blueSkin
        '
        Me.blueSkin.BackColor = System.Drawing.Color.Blue
        Me.blueSkin.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.blueSkin.Location = New System.Drawing.Point(332, 124)
        Me.blueSkin.Name = "blueSkin"
        Me.blueSkin.Size = New System.Drawing.Size(75, 42)
        Me.blueSkin.TabIndex = 17
        Me.blueSkin.UseVisualStyleBackColor = False
        '
        'redSkin
        '
        Me.redSkin.BackColor = System.Drawing.Color.Red
        Me.redSkin.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.redSkin.Location = New System.Drawing.Point(222, 124)
        Me.redSkin.Name = "redSkin"
        Me.redSkin.Size = New System.Drawing.Size(75, 42)
        Me.redSkin.TabIndex = 18
        Me.redSkin.UseVisualStyleBackColor = False
        '
        'defaultPreview
        '
        Me.defaultPreview.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.defaultPreview.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.defaultPreview.Location = New System.Drawing.Point(296, 9)
        Me.defaultPreview.Name = "defaultPreview"
        Me.defaultPreview.Size = New System.Drawing.Size(23, 25)
        Me.defaultPreview.TabIndex = 19
        Me.defaultPreview.UseVisualStyleBackColor = False
        '
        'grayPreview
        '
        Me.grayPreview.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.grayPreview.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.grayPreview.Location = New System.Drawing.Point(325, 9)
        Me.grayPreview.Name = "grayPreview"
        Me.grayPreview.Size = New System.Drawing.Size(23, 25)
        Me.grayPreview.TabIndex = 20
        Me.grayPreview.UseVisualStyleBackColor = False
        '
        'redPreview
        '
        Me.redPreview.BackColor = System.Drawing.Color.Red
        Me.redPreview.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.redPreview.Location = New System.Drawing.Point(354, 9)
        Me.redPreview.Name = "redPreview"
        Me.redPreview.Size = New System.Drawing.Size(23, 25)
        Me.redPreview.TabIndex = 21
        Me.redPreview.UseVisualStyleBackColor = False
        '
        'bluePreview
        '
        Me.bluePreview.BackColor = System.Drawing.Color.Blue
        Me.bluePreview.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.bluePreview.Location = New System.Drawing.Point(383, 9)
        Me.bluePreview.Name = "bluePreview"
        Me.bluePreview.Size = New System.Drawing.Size(23, 25)
        Me.bluePreview.TabIndex = 22
        Me.bluePreview.UseVisualStyleBackColor = False
        '
        'btn_Stop
        '
        Me.btn_Stop.BackColor = System.Drawing.Color.Transparent
        Me.btn_Stop.Image = Global.Minox_Player.My.Resources.Resources.blackStop
        Me.btn_Stop.Location = New System.Drawing.Point(205, 27)
        Me.btn_Stop.Name = "btn_Stop"
        Me.btn_Stop.Size = New System.Drawing.Size(32, 32)
        Me.btn_Stop.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.btn_Stop.TabIndex = 11
        Me.btn_Stop.TabStop = False
        '
        'btn_Pause
        '
        Me.btn_Pause.BackColor = System.Drawing.Color.Transparent
        Me.btn_Pause.Image = Global.Minox_Player.My.Resources.Resources.blackPause
        Me.btn_Pause.Location = New System.Drawing.Point(139, 27)
        Me.btn_Pause.Name = "btn_Pause"
        Me.btn_Pause.Size = New System.Drawing.Size(32, 32)
        Me.btn_Pause.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.btn_Pause.TabIndex = 10
        Me.btn_Pause.TabStop = False
        '
        'btn_Next
        '
        Me.btn_Next.BackColor = System.Drawing.Color.Transparent
        Me.btn_Next.Image = Global.Minox_Player.My.Resources.Resources.blackNext
        Me.btn_Next.Location = New System.Drawing.Point(236, 26)
        Me.btn_Next.Name = "btn_Next"
        Me.btn_Next.Size = New System.Drawing.Size(32, 32)
        Me.btn_Next.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.btn_Next.TabIndex = 12
        Me.btn_Next.TabStop = False
        '
        'btn_Prev
        '
        Me.btn_Prev.BackColor = System.Drawing.Color.Transparent
        Me.btn_Prev.Image = Global.Minox_Player.My.Resources.Resources.blackPrevious
        Me.btn_Prev.Location = New System.Drawing.Point(108, 26)
        Me.btn_Prev.Name = "btn_Prev"
        Me.btn_Prev.Size = New System.Drawing.Size(32, 32)
        Me.btn_Prev.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.btn_Prev.TabIndex = 13
        Me.btn_Prev.TabStop = False
        '
        'btn_Play
        '
        Me.btn_Play.BackColor = System.Drawing.Color.Transparent
        Me.btn_Play.Image = Global.Minox_Player.My.Resources.Resources.playback_play_icon_48
        Me.btn_Play.Location = New System.Drawing.Point(166, 19)
        Me.btn_Play.Name = "btn_Play"
        Me.btn_Play.Size = New System.Drawing.Size(48, 48)
        Me.btn_Play.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.btn_Play.TabIndex = 9
        Me.btn_Play.TabStop = False
        '
        'Themes_and_Skins
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(411, 178)
        Me.Controls.Add(Me.bluePreview)
        Me.Controls.Add(Me.redPreview)
        Me.Controls.Add(Me.grayPreview)
        Me.Controls.Add(Me.defaultPreview)
        Me.Controls.Add(Me.redSkin)
        Me.Controls.Add(Me.blueSkin)
        Me.Controls.Add(Me.silverSkin)
        Me.Controls.Add(Me.defaultSkin)
        Me.Controls.Add(Me.menuPanel)
        Me.Controls.Add(Me.Label1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Themes_and_Skins"
        Me.Text = "Minox Twecker"
        CType(Me.trackBarSeekBar, System.ComponentModel.ISupportInitialize).EndInit()
        Me.menuPanel.ResumeLayout(False)
        Me.menuPanel.PerformLayout()
        CType(Me.btn_Stop, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btn_Pause, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btn_Next, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btn_Prev, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btn_Play, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents trackBarSeekBar As System.Windows.Forms.TrackBar
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents btn_Pause As System.Windows.Forms.PictureBox
    Friend WithEvents btn_Prev As System.Windows.Forms.PictureBox
    Friend WithEvents btn_Next As System.Windows.Forms.PictureBox
    Friend WithEvents btn_Stop As System.Windows.Forms.PictureBox
    Friend WithEvents btn_Play As System.Windows.Forms.PictureBox
    Friend WithEvents menuPanel As System.Windows.Forms.Panel
    Friend WithEvents curentTime As System.Windows.Forms.Label
    Friend WithEvents maxTime As System.Windows.Forms.Label
    Friend WithEvents defaultSkin As System.Windows.Forms.Button
    Friend WithEvents silverSkin As System.Windows.Forms.Button
    Friend WithEvents blueSkin As System.Windows.Forms.Button
    Friend WithEvents redSkin As System.Windows.Forms.Button
    Friend WithEvents defaultPreview As System.Windows.Forms.Button
    Friend WithEvents grayPreview As System.Windows.Forms.Button
    Friend WithEvents redPreview As System.Windows.Forms.Button
    Friend WithEvents bluePreview As System.Windows.Forms.Button
End Class
