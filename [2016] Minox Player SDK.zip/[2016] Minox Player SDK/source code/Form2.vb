﻿Imports System.IO
Imports System.IO.Directory

Public Class Form2
    Dim w As IO.StreamWriter
    Dim r As IO.StreamReader
    Dim a, b As Integer
    Dim msdwn As Boolean = False
    Dim mediaList As New List(Of String)
    'creating NextTrack control
    Private Sub NextTrack()
        Try
            Dim s = PlayList1.SelectedIndex
            Dim f = Playlist.SelectedIndex
            PlayList1.SelectedIndex = s + 1
            Playlist.SelectedIndex = f + 1
            Play()
        Catch ex As Exception
            Form1.MediaPlayer.URL = ""
            'Play1.Text = "  Play"
        End Try
    End Sub
    'creating PreviousTrack control
    Private Sub PreviousTrack()
        Try
            Dim s = PlayList1.SelectedIndex
            Dim f = Playlist.SelectedIndex
            PlayList1.SelectedIndex = s - 1
            Playlist.SelectedIndex = f - 1
            Play()
        Catch ex As Exception
            Form1.MediaPlayer.URL = ""
            'Play1.Text = "  Play"
        End Try

    End Sub
    'declaring Play() sub procedure_______
    Private Sub Play()
        Try
            Form1.Timer2.Enabled = True
            Form1.Timer3.Enabled = True
            If Form1.MediaPlayer.playState = WMPLib.WMPPlayState.wmppsPaused Then
                Form1.MediaPlayer.Ctlcontrols.play()
            Else
                Form1.MediaPlayer.URL = PlayList1.SelectedItem
            End If
            'Form1.Play1.Text = "Pause"
        Catch ex As Exception

        End Try

    End Sub
    Private Sub btnNext(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Try
            NextTrack()
            Form1.Timer2.Enabled = True
            Me.Text = System.IO.Path.GetFileName(PlayList1.SelectedItem)
        Catch ex As Exception

        End Try

    End Sub

    Private Sub btnPrev(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Try
            PreviousTrack()
            Form1.Timer2.Enabled = True
            Me.Text = System.IO.Path.GetFileName(PlayList1.SelectedItem)
        Catch ex As Exception

        End Try

    End Sub
    'Setting playlist_Selection color = Red;

    Private Sub Playlist_MouseDoubleClick(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs)
        'Form1.Timer2.Stop()
        Try
            If Playlist.Items.Count = 0 = True Then
                MsgBox("Hej! playlista mi je prazna", MsgBoxStyle.Critical, "Napuni me i onda sviraj, do tada POZDRAV")
            Else
                Form1.MediaPlayer.URL = PlayList1.SelectedItem
            End If
            Me.Text = Playlist.SelectedItem
            Form1.Timer2.Enabled = True
            Form1.Timer3.Enabled = True
        Catch ex As Exception

        End Try

    End Sub
    'SelectedIndexChanged
    Private Sub Playlist_MouseDoubleClick_1(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) 'Handles Playlist.MouseDoubleClick
        ' Form1.Timer2.Stop()
        Try
            'Play1.Text = "   Pause"
            lblCount.Text = ": " & (Playlist.Items.Count.ToString)
            If Playlist.Items.Count = 0 = True Then
                MsgBox("Hej! playlista mi je prazna", MsgBoxStyle.Critical, "Napuni me i onda sviraj, do tada POZDRAV")
            Else
                Form1.MediaPlayer.URL = PlayList1.SelectedItem
            End If
            Me.Text = Playlist.SelectedItem
            Form1.Timer2.Enabled = True
            Form1.Timer3.Enabled = True
        Catch ex As Exception

        End Try

    End Sub
    Private Sub Playlist_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
        ''If Playlist2 SelectedIndex Changes, Playlist1 SelectedIndex Changes Too
        'Form1.Timer2.Stop()
        Try
            Form1.Timer2.Enabled = True
            Form1.Timer3.Enabled = True
            PlayList1.SelectedIndex = Playlist.SelectedIndex
        Catch ex As Exception

        End Try

    End Sub
    Public Class GetAllFiles

        Public Shared Function GetFileList(ByVal Dirpath As String) As List(Of String)
            Dim result As New List(Of String)
            Dim store As New Stack(Of String)
            store.Push(Dirpath)

            Do While (store.Count > 0)
                Dim dir As String = store.Pop
                Try
                    result.AddRange(Directory.GetFiles(dir, "*.mp3*"))
                    'change here to load music file in other formats. Not all formats are supported.
                    Dim directoryName As String
                    For Each directoryName In Directory.GetDirectories(dir)
                        store.Push(directoryName)
                    Next
                Catch ex As Exception
                End Try
            Loop
            Return result
        End Function
    End Class

    Private Sub LoadToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LoadToolStripMenuItem.Click
        'loadPlaylist;
        'function: loadPlaylist upon program startup;
        'developer: Amar Tufo 
        'verzija funkcije: 2.0
        'GREŠKA OTKLONJENA
        'Subota, 31 August 2013
        '*************************************************
        'ućitava Playlistu iz datoteke playlist.txt e
        ' i stora je u glavnoj playlisti sa ekstenzijom datoteka .mp3
        r = New IO.StreamReader("C:\playlist\playlist.txt")
        Try
            While (r.Peek() > -1)
                'initijalizuje Čitać tekstualne datoteke playlist.txt
                'učitava adrese datoteka koje se sviraju
                'npr: C:\Music\Track1.mp3
                Playlist.Items.Add(r.ReadLine)
                'prikazuje originalne datoteke sa ekstenzijom
                PlayList1.Items.Add(r.ReadLine)
                'prikazuje trenutan broj datoteka
                'koristi increment metodu i++ umjesto i = i+1
                lblCount.Text = ": " & (Playlist.Items.Count.ToString)
                Try
                    'onLoad prevent play
                    Form1.StopPlay()
                    'Obnova indeksa selekcije 
                    Playlist.SelectedIndex = 0
                    'sprećava automatsko reprodukovanje
                Catch ex As Exception 'sprećava grešku da se pojavi u funkciji
                End Try
            End While
            r.Close()
        Catch ex As Exception

        End Try


        '*******************************************************
       
    End Sub



    Private Sub Playlist_DragDrop1(ByVal sender As Object, ByVal e As System.Windows.Forms.DragEventArgs) Handles Playlist.DragDrop
        '  FolderDrag&Drop subprogram defined and declared on playlist level;
        '   Alows user to load multiple .mp3 items, to drag&play them in playlist;
        'User can add multiple .mp3 files directly to playlist, and play is utomaticly strating;
        '***************************************************************************************
        lblCount.Text = ": " & (Playlist.Items.Count.ToString)
        Try
            'Form1.Timer2.Stop()
            '*******************************
            Try
                'Multiitems loader  on Form mode;
                'Alows user to add entire .mp3 folder map directly to form and play;
                Try

                    'Form1.Timer2.Stop()
                    If e.Data.GetDataPresent(DataFormats.FileDrop) Then
                        Dim draggedFiles As String() = CType(e.Data.GetData(DataFormats.FileDrop), String())
                        Dim Files As String() = CType(e.Data.GetData(DataFormats.FileDrop), String())
                        For Each filename As String In draggedFiles
                            Playlist.Items.Add(FileIO.FileSystem.GetFileInfo(filename).Name)
                            PlayList1.Items.Add(filename)
                        Next
                        lblCount.Text = ": " & (Playlist.Items.Count.ToString)
                        Me.Text = Playlist.SelectedItem
                        PlayList1.SelectedIndex = 0
                        Playlist.SelectedIndex = 0
                    End If
                Catch ex As Exception

                End Try

            Catch ex As Exception
                'Form1.Timer2.Stop()
            End Try
            '******
            '*************************
            'Form1.Timer2.Stop()
            Dim colFiles() As String = e.Data.GetData(DataFormats.FileDrop, True)
            For i = 0 To colFiles.Count - 1
                Dim list As List(Of String) = Form2.GetAllFiles.GetFileList(colFiles(i))
                For Each path In list
                    Playlist.Items.Add(System.IO.Path.GetFileName(path))
                    PlayList1.Items.Add(path)
                Next
            Next
        Catch ex As Exception

        End Try

    End Sub

    Private Sub Playlist_DragEnter1(ByVal sender As Object, ByVal e As System.Windows.Forms.DragEventArgs) Handles Playlist.DragEnter
        'Playlist drag&drop enter subprogram which alows computer to read the folder on .mp3 files, and play them. . . 
        lblCount.Text = ": " & (Playlist.Items.Count.ToString)

        'Form1.Timer2.Stop()
        Try
            'Form1.Timer2.Stop()
            Try
                ' Form1.Timer2.Stop()
                'Form drag&drop enter subprogram which alows computer to read the folder on .mp3 files, and play them. . . 
                Try

                    'Form1.Timer2.Enabled = False
                    'Form1.Timer3.Enabled = False
                    If e.Data.GetDataPresent(DataFormats.FileDrop) Then
                        e.Effect = DragDropEffects.Copy
                    End If
                Catch ex As Exception

                End Try
            Catch ex As Exception
                'Form1.Timer2.Stop()
            End Try
            If e.Data.GetDataPresent(DataFormats.FileDrop) Then
                e.Effect = DragDropEffects.Copy
                lblCount.Text = ": " & (Playlist.Items.Count.ToString)
            Else
                'Form1.Timer2.Stop()
            End If
        Catch ex As Exception
            lblCount.Text = ": " & (Playlist.Items.Count.ToString)
        End Try
    End Sub

    Private Sub Playlist_DrawItem1(ByVal sender As Object, ByVal e As System.Windows.Forms.DrawItemEventArgs) Handles Playlist.DrawItem
        Try
            e.DrawBackground()
            If (e.State And DrawItemState.Selected) = DrawItemState.Selected Then
                e.Graphics.FillRectangle(Brushes.Red, e.Bounds)
            End If
            Using b As New SolidBrush(e.ForeColor)
                e.Graphics.DrawString(Playlist.GetItemText(Playlist.Items(e.Index)), e.Font, b, e.Bounds)
            End Using
            e.DrawFocusRectangle()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Playlist_MouseDoubleClick1(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles Playlist.MouseDoubleClick
        Form1.Timer5.Enabled = True
        Form1.trackStatus.Visible = True
        'Form1.trackStatus.Image = My.Resources.pause
        Form1.nowPlayling.Text = System.IO.Path.GetFileName(Playlist.SelectedItem)
        'notifyIconRegion = minoxPlaybackInfo; 
        Form1.NotifyIcon1.Visible = True
        Form1.NotifyIcon1.ShowBalloonTip(3000, "Now playing:", System.IO.Path.GetFileName(Playlist.SelectedItem), ToolTipIcon.Info)
        'when minox player start's the track it will change the image into pause;
        Try
            If Playlist.Items.Count = 0 = True Then
                MsgBox("Hej! playlista mi je prazna", MsgBoxStyle.Critical, "Napuni me i onda sviraj, do tada POZDRAV")
            Else
                Form1.StopPlay()
                Form1.MediaPlayer.URL = PlayList1.SelectedItem
            End If

        Catch ex As Exception

        End Try

    End Sub

   
    '************************************
    Private Sub DeleteToolStripMenuItem1_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DeleteToolStripMenuItem1.Click
        'Form1.Timer1.Stop()
        'this function is fixed
        PlayList1.Items.Remove(PlayList1.SelectedItem)
        Playlist.Items.Remove(Playlist.SelectedItem)
        lblCount.Text = " " & (Playlist.Items.Count.ToString)
    End Sub

    Private Sub ClearToolStripMenuItem1_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ClearToolStripMenuItem1.Click
        Try
            Playlist.Items.Clear()
            PlayList1.Items.Clear()
            lblCount.Text = " " & (Playlist.Items.Count.ToString)
        Catch ex As Exception

        End Try

    End Sub

    Private Sub SaveToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SaveToolStripMenuItem.Click
        'savePlaylist;
        'function: savePlaylist
        'developer: Amar Tufo
        'verzija funkcije: 2.0
        'GREŠKA OTKLONJENA
        'Subota, 31 August 2013

        'imamo malih problema sa dopustom registracije ekstenzije
        'tako da je ova funkcija playliste još uvijek pod testom;
        'javi mi grešku da ne može da registruje moj tip playliste koji je .minox
        'ukoliko se Minox Player ne pokrene kao administrator
        Dim i As Integer
        Try
            'kreira direktori playlist na disk C
            System.IO.Directory.CreateDirectory("C:\playlist")
            'spašava playlistu u playlist.txt tekstualnu datoteku
            'u prethodno kreiran direktori C:\playlist
            w = New IO.StreamWriter("C:\playlist\playlist.txt")
            For i = 0 To Playlist.Items.Count - 1
                'Spašava adresu svake pjesme u playlisti sa ekstenzijom
                w.WriteLine(Playlist.Items.Item(i))
                'spašava originalan naziv pjesme sa ekstenzijom
                w.WriteLine(PlayList1.Items.Item(i))
            Next
            w.Close()
        Catch ex As Exception
        End Try
    End Sub

    Private Sub AddToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AddToolStripMenuItem.Click
        'fixed openFilesDialog
        'developer: Amar Tufo
        'source fixes: VB.PLAYER v1.0.0
        'source fixes: Bass Utilities Test
        'fixed on 3, January 2015 (C) Amar Tufo
        Dim ofd As New OpenFileDialog
        ofd.FileName = Nothing
        ofd.Title = "Load Music"
        ofd.Filter = "Song File(*.mp3;*.wav)|*.mp3;*.wav|All File(*.*)|*.*"
        ofd.Multiselect = True
        ofd.ShowDialog()
        'Nedostaje enumerator Playliste
        'On bi trebao da nabraja svaku novu dodanu datoteku
        'Kao npr: "1.Track1.mp3", "2.Track2.mp3", "3.Track3.mp3" . . . "Track.mp3 +++"
        Try
            For I As Integer = 0 To ofd.FileNames.Count - 1
                Me.PlayList1.Items.Add(ofd.FileNames(I.ToString))
                Me.Playlist.Items.Add(ofd.SafeFileNames(I.ToString))
                Me.lblCount.Text = ": " & (Me.Playlist.Items.Count.ToString)
            Next
            If PlayList1.Items.Count = 0 = True Then
                MsgBox("You suck '''", MsgBoxStyle.Critical, "ERROR")
            Else
                PlayList1.SelectedIndex = 0
                Playlist.SelectedIndex = 0
            End If
        Catch ex As Exception
        End Try
    End Sub
    
    'this part of code is implementation for bordleesForm();
    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        a = Cursor.Position.X - Me.Location.X
        b = Cursor.Position.Y - Me.Location.Y
    End Sub
    Private Sub playlistLogo_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles playlistLogo.MouseDown
        msdwn = True
    End Sub

    Private Sub playlistLogo_MouseMove(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles playlistLogo.MouseMove
        If msdwn = True Then
            Me.Left = Cursor.Position.X - a
            Me.Top = Cursor.Position.Y - b
        End If
    End Sub

    Private Sub playlistLogo_MouseUp(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles playlistLogo.MouseUp
        msdwn = False
    End Sub

    Private Sub Label2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles minimizeApp.Click
        Me.WindowState = FormWindowState.Minimized
    End Sub
    'this method does not produce function
    Private Sub Form2_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing

    End Sub
    'setting CrystalClear as DefaultFont
    Private Sub Form2_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        'this is highly experimental code
        'For fadein = 0.0 To 1.1 Step 0.1
        'Me.Opacity = fadein
        'Me.Refresh()
        'Threading.Thread.Sleep(100)
        'Next
        'uper code is fadeIn_Effect 
        'declaration date: 2, January 2015
        'developer: Amar Tufo, 2015 AllRightsReserved
        '_________________________________________________
        playlistLogo.Font = CustomFont.GetInstance(12, FontStyle.Bold)
        minimizeApp.Font = CustomFont.GetInstance(20, FontStyle.Bold)
        closeApp.Font = CustomFont.GetInstance(17, FontStyle.Bold)
        Playlist.ForeColor = Color.Lime
    End Sub

    Private Sub closeApp_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles closeApp.Click
        Me.Hide()
    End Sub
    'closeApp:--> mouseHover_Event()
    Private Sub closeApp_MouseEnter(ByVal sender As Object, ByVal e As System.EventArgs) Handles closeApp.MouseEnter
        closeApp.ForeColor = Color.Red
    End Sub

    Private Sub closeApp_MouseLeave(ByVal sender As Object, ByVal e As System.EventArgs) Handles closeApp.MouseLeave
        closeApp.ForeColor = Color.White
    End Sub

    Private Sub Playlist_SelectedIndexChanged_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Playlist.SelectedIndexChanged
        PlayList1.SelectedIndex = Playlist.SelectedIndex

    End Sub
End Class