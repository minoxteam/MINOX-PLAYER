﻿Public Class Themes_and_Skins

    Private Sub Themes_and_Skins_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Private Sub defaultSkin_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles defaultSkin.Click
        Form1.trackBarSeekBar.BackColor = Color.DarkRed
        Form1.menuPanel.BackColor = Color.DarkRed
    End Sub

    Private Sub silverSkin_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles silverSkin.Click
        Form1.trackBarSeekBar.BackColor = Color.LightGray
        Form1.menuPanel.BackColor = Color.LightGray
        Form1.maxValue.ForeColor = Color.Black
        Form1.minValue.ForeColor = Color.Black
    End Sub

    Private Sub defaultPreview_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles defaultPreview.Click
        trackBarSeekBar.BackColor = Color.IndianRed
        menuPanel.BackColor = Color.IndianRed
        curentTime.ForeColor = Color.White
        maxTime.ForeColor = Color.White
    End Sub

    Private Sub grayPreview_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles grayPreview.Click
        trackBarSeekBar.BackColor = Color.LightGray
        menuPanel.BackColor = Color.LightGray
        curentTime.ForeColor = Color.Black
        maxTime.ForeColor = Color.Black
    End Sub

    Private Sub redSkin_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles redSkin.Click
        Form1.trackBarSeekBar.BackColor = Color.Red
        Form1.menuPanel.BackColor = Color.Red
        Form1.minValue.ForeColor = Color.White
        Form1.maxValue.ForeColor = Color.White
    End Sub

    Private Sub bluePreview_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles bluePreview.Click
        trackBarSeekBar.BackColor = Color.Blue
        menuPanel.BackColor = Color.Blue
        curentTime.ForeColor = Color.White
        maxTime.ForeColor = Color.White
    End Sub

    Private Sub redPreview_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles redPreview.Click
        trackBarSeekBar.BackColor = Color.Red
        menuPanel.BackColor = Color.Red
        curentTime.ForeColor = Color.Red
        maxTime.ForeColor = Color.Red
    End Sub

    Private Sub blueSkin_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles blueSkin.Click
        Form1.trackBarSeekBar.BackColor = Color.Blue
        Form1.menuPanel.BackColor = Color.Blue
        Form1.minValue.ForeColor = Color.White
        Form1.maxValue.ForeColor = Color.White
    End Sub

    Private Sub trackBarSeekBar_Scroll(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles trackBarSeekBar.Scroll
        Try
            trackBarSeekBar.Enabled = False
        Catch ex As Exception

        End Try
    End Sub
End Class