﻿Imports System.Drawing.Text
Imports System.Runtime.InteropServices
Public Class Form3
    Dim a, b As Integer
    Dim msdwn As Boolean = False
    Private Sub CheckBox1_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles repeatTrack.CheckedChanged
        Try
            Form1.MediaPlayer.settings.setMode("loop", True)
            If repeatTrack.Checked = True Then
                Form1.NotifyIcon1.Visible = True
                Form1.NotifyIcon1.ShowBalloonTip(3000, "Minox Player:", ("repeatSingleTrack is now ON"), ToolTipIcon.Info)
                Form1.MediaPlayer.settings.setMode("loop", True)
                '******************** it displays the curent song which is playing *************************************************************

            ElseIf repeatTrack.Checked = False Then
                Form1.NotifyIcon1.Visible = True
                Form1.NotifyIcon1.ShowBalloonTip(3000, "Minox Player:", ("repeatSingleTrack is now OFF"), ToolTipIcon.Info)
                Form1.MediaPlayer.settings.setMode("loop", False)
            End If
        Catch ex As Exception

        End Try

    End Sub

    Private Sub Label2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles minimizeApp.Click
        Me.WindowState = FormWindowState.Minimized
    End Sub
    Private Sub playModeLogo_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles playModeLogo.MouseDown
        msdwn = True
    End Sub

    Private Sub playModeLogo_MouseMove(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles playModeLogo.MouseMove
        If msdwn = True Then
            Me.Left = Cursor.Position.X - a
            Me.Top = Cursor.Position.Y - b
        End If
    End Sub

    Private Sub playModeLogo_MouseUp(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles playModeLogo.MouseUp
        msdwn = False
    End Sub

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        a = Cursor.Position.X - Me.Location.X
        b = Cursor.Position.Y - Me.Location.Y
    End Sub

    Private Sub playMode_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub Timer2_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer2.Tick
        'If PlayItems.Checked = True Then
        'Try
        'Form2.Playlist.SelectedIndex = Form2.Playlist.SelectedIndex + 1
        'Form1.MediaPlayer.URL = Form2.Playlist.SelectedItem

        'Catch ex As Exception '--------- when it gets to the last index, instead of error, it goes back to the top of the list
        'Form2.Playlist.SelectedIndex = (0)
        'Form1.MediaPlayer.URL = Form2.Playlist.SelectedItem
        'Form1.MediaPlayer.Ctlcontrols.play()
        'End Try
        'End If
    End Sub

    Private Sub Form3_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        ' Form1.Timer8.Enabled = False
    End Sub

    Private Sub Form3_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Form1.Timer8.Enabled = True
        PlayItems.Font = CustomFont.GetInstance(10, FontStyle.Bold)
        repeatTrack.Font = CustomFont.GetInstance(10, FontStyle.Bold)
        playModeLogo.Font = CustomFont.GetInstance(12, FontStyle.Bold)
        minimizeApp.Font = CustomFont.GetInstance(20, FontStyle.Bold)
        closeApp.Font = CustomFont.GetInstance(17, FontStyle.Bold)
    End Sub

    Private Sub PlayItems_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PlayItems.CheckedChanged
        If PlayItems.Checked = True Then
            Form1.NotifyIcon1.Visible = True
            Form1.NotifyIcon1.ShowBalloonTip(3000, "Minox Player:", ("repeatPlaylist is now ON"), ToolTipIcon.Info)
        ElseIf PlayItems.Checked = False Then
            Form1.NotifyIcon1.Visible = True
            Form1.NotifyIcon1.ShowBalloonTip(3000, "Minox Player:", ("repeatPlaylist is now OFF"), ToolTipIcon.Info)
        End If
    End Sub

    Private Sub closeApp_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles closeApp.Click
        'Form1.Timer8.Enabled = True

        Me.Hide()
    End Sub

    Private Sub closeApp_MouseEnter(ByVal sender As Object, ByVal e As System.EventArgs) Handles closeApp.MouseEnter
        closeApp.ForeColor = Color.Red
    End Sub

    Private Sub closeApp_MouseLeave(ByVal sender As Object, ByVal e As System.EventArgs) Handles closeApp.MouseLeave
        closeApp.ForeColor = Color.White
    End Sub
End Class