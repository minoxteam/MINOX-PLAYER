﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form3
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form3))
        Me.repeatTrack = New System.Windows.Forms.CheckBox
        Me.PlayItems = New System.Windows.Forms.CheckBox
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer2 = New System.Windows.Forms.Timer(Me.components)
        Me.repeatTrackStatus = New System.Windows.Forms.Button
        Me.repeatStatus = New System.Windows.Forms.Button
        Me.playModeHead = New System.Windows.Forms.Panel
        Me.closeApp = New System.Windows.Forms.Label
        Me.minimizeApp = New System.Windows.Forms.Label
        Me.playModeLogo = New System.Windows.Forms.Label
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.playModeHead.SuspendLayout()
        Me.SuspendLayout()
        '
        'repeatTrack
        '
        Me.repeatTrack.AutoSize = True
        Me.repeatTrack.BackColor = System.Drawing.Color.Transparent
        Me.repeatTrack.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.repeatTrack.ForeColor = System.Drawing.Color.White
        Me.repeatTrack.Location = New System.Drawing.Point(77, 107)
        Me.repeatTrack.Name = "repeatTrack"
        Me.repeatTrack.Size = New System.Drawing.Size(79, 21)
        Me.repeatTrack.TabIndex = 1
        Me.repeatTrack.Text = "repeatOne"
        Me.ToolTip1.SetToolTip(Me.repeatTrack, "Play single track!")
        Me.repeatTrack.UseCompatibleTextRendering = True
        Me.repeatTrack.UseVisualStyleBackColor = False
        '
        'PlayItems
        '
        Me.PlayItems.AutoSize = True
        Me.PlayItems.BackColor = System.Drawing.Color.Transparent
        Me.PlayItems.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.749999!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PlayItems.ForeColor = System.Drawing.Color.White
        Me.PlayItems.Location = New System.Drawing.Point(76, 61)
        Me.PlayItems.Name = "PlayItems"
        Me.PlayItems.Size = New System.Drawing.Size(79, 21)
        Me.PlayItems.TabIndex = 31
        Me.PlayItems.Text = "repeatAll"
        Me.ToolTip1.SetToolTip(Me.PlayItems, "Play all over again!")
        Me.PlayItems.UseCompatibleTextRendering = True
        Me.PlayItems.UseVisualStyleBackColor = False
        '
        'Timer1
        '
        Me.Timer1.Enabled = True
        '
        'Timer2
        '
        Me.Timer2.Enabled = True
        Me.Timer2.Interval = 1000
        '
        'repeatTrackStatus
        '
        Me.repeatTrackStatus.BackColor = System.Drawing.Color.Transparent
        Me.repeatTrackStatus.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.repeatTrackStatus.Image = Global.Minox_Player.My.Resources.Resources._1377648823_519548_044_Repeat
        Me.repeatTrackStatus.Location = New System.Drawing.Point(30, 54)
        Me.repeatTrackStatus.Name = "repeatTrackStatus"
        Me.repeatTrackStatus.Size = New System.Drawing.Size(41, 31)
        Me.repeatTrackStatus.TabIndex = 36
        Me.repeatTrackStatus.UseVisualStyleBackColor = False
        '
        'repeatStatus
        '
        Me.repeatStatus.BackColor = System.Drawing.Color.Transparent
        Me.repeatStatus.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.repeatStatus.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.repeatStatus.Image = Global.Minox_Player.My.Resources.Resources._1377649175_media_repeat_alt
        Me.repeatStatus.Location = New System.Drawing.Point(30, 100)
        Me.repeatStatus.Name = "repeatStatus"
        Me.repeatStatus.Size = New System.Drawing.Size(41, 31)
        Me.repeatStatus.TabIndex = 35
        Me.repeatStatus.UseVisualStyleBackColor = False
        '
        'playModeHead
        '
        Me.playModeHead.BackgroundImage = Global.Minox_Player.My.Resources.Resources.playModeHead_Metal
        Me.playModeHead.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.playModeHead.Controls.Add(Me.closeApp)
        Me.playModeHead.Controls.Add(Me.minimizeApp)
        Me.playModeHead.Controls.Add(Me.playModeLogo)
        Me.playModeHead.Location = New System.Drawing.Point(0, 0)
        Me.playModeHead.Name = "playModeHead"
        Me.playModeHead.Size = New System.Drawing.Size(233, 35)
        Me.playModeHead.TabIndex = 32
        '
        'closeApp
        '
        Me.closeApp.AutoSize = True
        Me.closeApp.BackColor = System.Drawing.Color.Transparent
        Me.closeApp.Font = New System.Drawing.Font("Microsoft Sans Serif", 17.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.closeApp.ForeColor = System.Drawing.Color.White
        Me.closeApp.Location = New System.Drawing.Point(207, 0)
        Me.closeApp.Name = "closeApp"
        Me.closeApp.Size = New System.Drawing.Size(20, 32)
        Me.closeApp.TabIndex = 35
        Me.closeApp.Text = "x"
        Me.ToolTip1.SetToolTip(Me.closeApp, "Close playMode!")
        Me.closeApp.UseCompatibleTextRendering = True
        '
        'minimizeApp
        '
        Me.minimizeApp.AutoSize = True
        Me.minimizeApp.BackColor = System.Drawing.Color.Transparent
        Me.minimizeApp.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.minimizeApp.ForeColor = System.Drawing.Color.White
        Me.minimizeApp.Location = New System.Drawing.Point(2, -2)
        Me.minimizeApp.Name = "minimizeApp"
        Me.minimizeApp.Size = New System.Drawing.Size(19, 37)
        Me.minimizeApp.TabIndex = 34
        Me.minimizeApp.Text = "-"
        Me.minimizeApp.UseCompatibleTextRendering = True
        '
        'playModeLogo
        '
        Me.playModeLogo.AutoSize = True
        Me.playModeLogo.BackColor = System.Drawing.Color.Transparent
        Me.playModeLogo.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.playModeLogo.ForeColor = System.Drawing.Color.White
        Me.playModeLogo.Location = New System.Drawing.Point(67, 6)
        Me.playModeLogo.Name = "playModeLogo"
        Me.playModeLogo.Size = New System.Drawing.Size(73, 22)
        Me.playModeLogo.TabIndex = 33
        Me.playModeLogo.Text = "playMode"
        Me.playModeLogo.UseCompatibleTextRendering = True
        '
        'Form3
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.Minox_Player.My.Resources.Resources.playModeCover_Metal
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.ClientSize = New System.Drawing.Size(233, 145)
        Me.Controls.Add(Me.repeatTrackStatus)
        Me.Controls.Add(Me.repeatStatus)
        Me.Controls.Add(Me.playModeHead)
        Me.Controls.Add(Me.PlayItems)
        Me.Controls.Add(Me.repeatTrack)
        Me.DoubleBuffered = True
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Form3"
        Me.Text = "  "
        Me.playModeHead.ResumeLayout(False)
        Me.playModeHead.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents repeatTrack As System.Windows.Forms.CheckBox
    Friend WithEvents PlayItems As System.Windows.Forms.CheckBox
    Friend WithEvents playModeHead As System.Windows.Forms.Panel
    Friend WithEvents playModeLogo As System.Windows.Forms.Label
    Friend WithEvents minimizeApp As System.Windows.Forms.Label
    Friend WithEvents closeApp As System.Windows.Forms.Label
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents Timer2 As System.Windows.Forms.Timer
    Friend WithEvents repeatStatus As System.Windows.Forms.Button
    Friend WithEvents repeatTrackStatus As System.Windows.Forms.Button
    Friend WithEvents ToolTip1 As System.Windows.Forms.ToolTip
End Class
