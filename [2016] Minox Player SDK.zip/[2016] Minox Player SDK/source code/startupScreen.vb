﻿Public NotInheritable Class startupScreen
    'HIGHLY EXPERIMENTAL
    Private Sub startupScreen_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
       
    End Sub

    'TODO: This form can easily be set as the splash screen for the application by going to the "Application" tab
    '  of the Project Designer ("Properties" under the "Project" menu).

    'HIGHLY EXPERIMENTAL
    Private Sub startupScreen_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
       
    End Sub

End Class
