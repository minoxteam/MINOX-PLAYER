﻿Public Class About

    Private Sub facebookLink_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles facebookLink.Click
        System.Diagnostics.Process.Start("http://www.facebook.com/MinoxPlayer")
    End Sub

    Private Sub bloggerLink_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles bloggerLink.Click
        System.Diagnostics.Process.Start("http://www.minoxmp3player.blogspot.com")
    End Sub

    Private Sub myFacebookLink_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles myFacebookLink.Click
        System.Diagnostics.Process.Start("http://www.facebook.com/ubuntuBoy")
    End Sub
End Class