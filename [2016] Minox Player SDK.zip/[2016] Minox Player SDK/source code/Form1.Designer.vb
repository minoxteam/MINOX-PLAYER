﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Dim ColorLinearGradient2 As gTrackBar.ColorLinearGradient = New gTrackBar.ColorLinearGradient
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.Styler = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.PlaylistColorToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.BlackToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.DodgerBlueToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.WhiteToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem
        Me.TextColorwToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.WhiteToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.RedToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.DodgerBlueToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem
        Me.BlackToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem
        Me.LimeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.PlayModeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.AddFolderToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.PlaylistToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ThemesAndSkinsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.technologyBlue = New System.Windows.Forms.ToolStripMenuItem
        Me.techOrange = New System.Windows.Forms.ToolStripMenuItem
        Me.metalTheme = New System.Windows.Forms.ToolStripMenuItem
        Me.pinkThemes = New System.Windows.Forms.ToolStripMenuItem
        Me.orangeThema = New System.Windows.Forms.ToolStripMenuItem
        Me.brownThema = New System.Windows.Forms.ToolStripMenuItem
        Me.darkGray = New System.Windows.Forms.ToolStripMenuItem
        Me.purpleThema = New System.Windows.Forms.ToolStripMenuItem
        Me.blackThemaX = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator
        Me.flatBrown_Thema = New System.Windows.Forms.ToolStripMenuItem
        Me.greenLime = New System.Windows.Forms.ToolStripMenuItem
        Me.ImportToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.AboutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ColorDialog1 = New System.Windows.Forms.ColorDialog
        Me.Txt_TrackName = New System.Windows.Forms.TextBox
        Me.NotifyIcon1 = New System.Windows.Forms.NotifyIcon(Me.components)
        Me.MinoxAgent = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.gnu_Play = New System.Windows.Forms.ToolStripMenuItem
        Me.gnu_Pause = New System.Windows.Forms.ToolStripMenuItem
        Me.gnu_Stop = New System.Windows.Forms.ToolStripMenuItem
        Me.gnu_Next = New System.Windows.Forms.ToolStripMenuItem
        Me.gnu_Previous = New System.Windows.Forms.ToolStripMenuItem
        Me.mnPlaylist = New System.Windows.Forms.ToolStripMenuItem
        Me.addMusic = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator
        Me.ourFacebook = New System.Windows.Forms.ToolStripMenuItem
        Me.ourBlog = New System.Windows.Forms.ToolStripMenuItem
        Me.aboutMinoxPlayer = New System.Windows.Forms.ToolStripMenuItem
        Me.exitApp = New System.Windows.Forms.ToolStripMenuItem
        Me.minoxSubMenu = New System.Windows.Forms.ToolStripMenuItem
        Me.Timer2 = New System.Windows.Forms.Timer(Me.components)
        Me.volumeCounter = New System.Windows.Forms.Label
        Me.volumeBar = New gTrackBar.gTrackBar
        Me.HScrollBar1 = New System.Windows.Forms.HScrollBar
        Me.menuPanel = New System.Windows.Forms.Panel
        Me.PictureBox1 = New System.Windows.Forms.PictureBox
        Me.btn_Prev = New System.Windows.Forms.PictureBox
        Me.btn_Pause = New System.Windows.Forms.PictureBox
        Me.btn_Play = New System.Windows.Forms.PictureBox
        Me.btn_Next = New System.Windows.Forms.PictureBox
        Me.btn_Stop = New System.Windows.Forms.PictureBox
        Me.repeatPlay = New System.Windows.Forms.CheckBox
        Me.gTrackBar1 = New gTrackBar.gTrackBar
        Me.maxValue = New System.Windows.Forms.Label
        Me.minValue = New System.Windows.Forms.Label
        Me.trackBarSeekBar = New System.Windows.Forms.TrackBar
        Me.Timer3 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer4 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer5 = New System.Windows.Forms.Timer(Me.components)
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog
        Me.btn_PlayList = New System.Windows.Forms.PictureBox
        Me.btn_Volume = New System.Windows.Forms.PictureBox
        Me.Play1 = New System.Windows.Forms.Button
        Me.Next1 = New System.Windows.Forms.Button
        Me.slideDown = New System.Windows.Forms.PictureBox
        Me.slideUp = New System.Windows.Forms.PictureBox
        Me.Stop1 = New System.Windows.Forms.Button
        Me.btn_Add = New System.Windows.Forms.PictureBox
        Me.Prev1 = New System.Windows.Forms.Button
        Me.FullMode = New System.Windows.Forms.Button
        Me.minoxHead = New System.Windows.Forms.Panel
        Me.exitProgram = New System.Windows.Forms.Label
        Me.minoxLogo = New System.Windows.Forms.Label
        Me.minimizeProgram = New System.Windows.Forms.Label
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip
        Me.nowPlayling = New System.Windows.Forms.Label
        Me.myVolumeBar = New XComponent.SliderBar.MACTrackBar
        Me.Timer6 = New System.Windows.Forms.Timer(Me.components)
        Me.trackStatus = New System.Windows.Forms.Label
        Me.myVolumePanel = New System.Windows.Forms.Panel
        Me.MediaPlayer = New AxWMPLib.AxWindowsMediaPlayer
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.Timer7 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer8 = New System.Windows.Forms.Timer(Me.components)
        Me.Styler.SuspendLayout()
        Me.MinoxAgent.SuspendLayout()
        Me.menuPanel.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btn_Prev, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btn_Pause, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btn_Play, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btn_Next, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btn_Stop, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.trackBarSeekBar, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btn_PlayList, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btn_Volume, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.slideDown, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.slideUp, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btn_Add, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.minoxHead.SuspendLayout()
        Me.MenuStrip1.SuspendLayout()
        Me.myVolumePanel.SuspendLayout()
        CType(Me.MediaPlayer, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Timer1
        '
        Me.Timer1.Enabled = True
        Me.Timer1.Interval = 1
        '
        'Styler
        '
        Me.Styler.BackColor = System.Drawing.Color.Silver
        Me.Styler.BackgroundImage = Global.Minox_Player.My.Resources.Resources.minoxStyler_Metal
        Me.Styler.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Styler.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.PlaylistColorToolStripMenuItem, Me.TextColorwToolStripMenuItem, Me.PlayModeToolStripMenuItem, Me.AddFolderToolStripMenuItem, Me.PlaylistToolStripMenuItem, Me.ThemesAndSkinsToolStripMenuItem, Me.ImportToolStripMenuItem, Me.AboutToolStripMenuItem})
        Me.Styler.Name = "ContextMenuStrip1"
        Me.Styler.ShowItemToolTips = False
        Me.Styler.Size = New System.Drawing.Size(172, 202)
        '
        'PlaylistColorToolStripMenuItem
        '
        Me.PlaylistColorToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BlackToolStripMenuItem, Me.DodgerBlueToolStripMenuItem, Me.WhiteToolStripMenuItem1})
        Me.PlaylistColorToolStripMenuItem.ForeColor = System.Drawing.Color.White
        Me.PlaylistColorToolStripMenuItem.Image = Global.Minox_Player.My.Resources.Resources._1377649325_Playlist
        Me.PlaylistColorToolStripMenuItem.Name = "PlaylistColorToolStripMenuItem"
        Me.PlaylistColorToolStripMenuItem.Size = New System.Drawing.Size(171, 22)
        Me.PlaylistColorToolStripMenuItem.Text = "Playlist Color"
        '
        'BlackToolStripMenuItem
        '
        Me.BlackToolStripMenuItem.Name = "BlackToolStripMenuItem"
        Me.BlackToolStripMenuItem.Size = New System.Drawing.Size(151, 22)
        Me.BlackToolStripMenuItem.Text = "1. Black"
        '
        'DodgerBlueToolStripMenuItem
        '
        Me.DodgerBlueToolStripMenuItem.Name = "DodgerBlueToolStripMenuItem"
        Me.DodgerBlueToolStripMenuItem.Size = New System.Drawing.Size(151, 22)
        Me.DodgerBlueToolStripMenuItem.Text = "2. Dodger Blue"
        '
        'WhiteToolStripMenuItem1
        '
        Me.WhiteToolStripMenuItem1.Name = "WhiteToolStripMenuItem1"
        Me.WhiteToolStripMenuItem1.Size = New System.Drawing.Size(151, 22)
        Me.WhiteToolStripMenuItem1.Text = "3. White"
        '
        'TextColorwToolStripMenuItem
        '
        Me.TextColorwToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.WhiteToolStripMenuItem, Me.RedToolStripMenuItem, Me.DodgerBlueToolStripMenuItem1, Me.BlackToolStripMenuItem1, Me.LimeToolStripMenuItem})
        Me.TextColorwToolStripMenuItem.ForeColor = System.Drawing.Color.White
        Me.TextColorwToolStripMenuItem.Image = Global.Minox_Player.My.Resources.Resources.color_line
        Me.TextColorwToolStripMenuItem.Name = "TextColorwToolStripMenuItem"
        Me.TextColorwToolStripMenuItem.Size = New System.Drawing.Size(171, 22)
        Me.TextColorwToolStripMenuItem.Text = "Text Color"
        '
        'WhiteToolStripMenuItem
        '
        Me.WhiteToolStripMenuItem.Name = "WhiteToolStripMenuItem"
        Me.WhiteToolStripMenuItem.Size = New System.Drawing.Size(151, 22)
        Me.WhiteToolStripMenuItem.Text = "1. White"
        '
        'RedToolStripMenuItem
        '
        Me.RedToolStripMenuItem.Name = "RedToolStripMenuItem"
        Me.RedToolStripMenuItem.Size = New System.Drawing.Size(151, 22)
        Me.RedToolStripMenuItem.Text = "2. Red"
        '
        'DodgerBlueToolStripMenuItem1
        '
        Me.DodgerBlueToolStripMenuItem1.Name = "DodgerBlueToolStripMenuItem1"
        Me.DodgerBlueToolStripMenuItem1.Size = New System.Drawing.Size(151, 22)
        Me.DodgerBlueToolStripMenuItem1.Text = "3. Dodger Blue"
        '
        'BlackToolStripMenuItem1
        '
        Me.BlackToolStripMenuItem1.Name = "BlackToolStripMenuItem1"
        Me.BlackToolStripMenuItem1.Size = New System.Drawing.Size(151, 22)
        Me.BlackToolStripMenuItem1.Text = "4. Black"
        '
        'LimeToolStripMenuItem
        '
        Me.LimeToolStripMenuItem.Name = "LimeToolStripMenuItem"
        Me.LimeToolStripMenuItem.Size = New System.Drawing.Size(151, 22)
        Me.LimeToolStripMenuItem.Text = "5. Lime"
        '
        'PlayModeToolStripMenuItem
        '
        Me.PlayModeToolStripMenuItem.ForeColor = System.Drawing.Color.White
        Me.PlayModeToolStripMenuItem.Image = Global.Minox_Player.My.Resources.Resources.PlayAll
        Me.PlayModeToolStripMenuItem.Name = "PlayModeToolStripMenuItem"
        Me.PlayModeToolStripMenuItem.Size = New System.Drawing.Size(171, 22)
        Me.PlayModeToolStripMenuItem.Text = "playMode"
        '
        'AddFolderToolStripMenuItem
        '
        Me.AddFolderToolStripMenuItem.ForeColor = System.Drawing.Color.White
        Me.AddFolderToolStripMenuItem.Image = Global.Minox_Player.My.Resources.Resources.blackFolder
        Me.AddFolderToolStripMenuItem.Name = "AddFolderToolStripMenuItem"
        Me.AddFolderToolStripMenuItem.Size = New System.Drawing.Size(171, 22)
        Me.AddFolderToolStripMenuItem.Text = "Add folder"
        '
        'PlaylistToolStripMenuItem
        '
        Me.PlaylistToolStripMenuItem.BackColor = System.Drawing.Color.Silver
        Me.PlaylistToolStripMenuItem.ForeColor = System.Drawing.Color.White
        Me.PlaylistToolStripMenuItem.Image = CType(resources.GetObject("PlaylistToolStripMenuItem.Image"), System.Drawing.Image)
        Me.PlaylistToolStripMenuItem.Name = "PlaylistToolStripMenuItem"
        Me.PlaylistToolStripMenuItem.Size = New System.Drawing.Size(171, 22)
        Me.PlaylistToolStripMenuItem.Text = "Playlist"
        '
        'ThemesAndSkinsToolStripMenuItem
        '
        Me.ThemesAndSkinsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.technologyBlue, Me.techOrange, Me.metalTheme, Me.pinkThemes, Me.orangeThema, Me.brownThema, Me.darkGray, Me.purpleThema, Me.blackThemaX, Me.ToolStripSeparator2, Me.flatBrown_Thema, Me.greenLime})
        Me.ThemesAndSkinsToolStripMenuItem.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.ThemesAndSkinsToolStripMenuItem.ForeColor = System.Drawing.Color.White
        Me.ThemesAndSkinsToolStripMenuItem.Image = Global.Minox_Player.My.Resources.Resources.music1
        Me.ThemesAndSkinsToolStripMenuItem.Name = "ThemesAndSkinsToolStripMenuItem"
        Me.ThemesAndSkinsToolStripMenuItem.Size = New System.Drawing.Size(171, 22)
        Me.ThemesAndSkinsToolStripMenuItem.Text = "Themes and Skins"
        '
        'technologyBlue
        '
        Me.technologyBlue.Name = "technologyBlue"
        Me.technologyBlue.Size = New System.Drawing.Size(160, 22)
        Me.technologyBlue.Text = "1. Tech Blue"
        '
        'techOrange
        '
        Me.techOrange.Name = "techOrange"
        Me.techOrange.Size = New System.Drawing.Size(160, 22)
        Me.techOrange.Text = "2. Tech Orange"
        '
        'metalTheme
        '
        Me.metalTheme.Name = "metalTheme"
        Me.metalTheme.Size = New System.Drawing.Size(160, 22)
        Me.metalTheme.Text = "3. Metal Thema"
        '
        'pinkThemes
        '
        Me.pinkThemes.Name = "pinkThemes"
        Me.pinkThemes.Size = New System.Drawing.Size(160, 22)
        Me.pinkThemes.Text = "4. Light Pink"
        '
        'orangeThema
        '
        Me.orangeThema.Name = "orangeThema"
        Me.orangeThema.Size = New System.Drawing.Size(160, 22)
        Me.orangeThema.Text = "5. Light Orange"
        '
        'brownThema
        '
        Me.brownThema.Name = "brownThema"
        Me.brownThema.Size = New System.Drawing.Size(160, 22)
        Me.brownThema.Text = "8. Brown Thema"
        '
        'darkGray
        '
        Me.darkGray.Name = "darkGray"
        Me.darkGray.Size = New System.Drawing.Size(160, 22)
        Me.darkGray.Text = "6. Dark Gray"
        '
        'purpleThema
        '
        Me.purpleThema.Name = "purpleThema"
        Me.purpleThema.Size = New System.Drawing.Size(160, 22)
        Me.purpleThema.Text = "7. Purple Thema"
        '
        'blackThemaX
        '
        Me.blackThemaX.Name = "blackThemaX"
        Me.blackThemaX.Size = New System.Drawing.Size(160, 22)
        Me.blackThemaX.Text = "8. Black Thema"
        '
        'ToolStripSeparator2
        '
        Me.ToolStripSeparator2.Name = "ToolStripSeparator2"
        Me.ToolStripSeparator2.Size = New System.Drawing.Size(157, 6)
        '
        'flatBrown_Thema
        '
        Me.flatBrown_Thema.Name = "flatBrown_Thema"
        Me.flatBrown_Thema.Size = New System.Drawing.Size(160, 22)
        Me.flatBrown_Thema.Text = "Flat Style"
        '
        'greenLime
        '
        Me.greenLime.Name = "greenLime"
        Me.greenLime.Size = New System.Drawing.Size(160, 22)
        Me.greenLime.Text = "Lime Thema"
        '
        'ImportToolStripMenuItem
        '
        Me.ImportToolStripMenuItem.BackColor = System.Drawing.Color.Silver
        Me.ImportToolStripMenuItem.ForeColor = System.Drawing.Color.White
        Me.ImportToolStripMenuItem.Image = Global.Minox_Player.My.Resources.Resources.Folder_Add_icon1
        Me.ImportToolStripMenuItem.Name = "ImportToolStripMenuItem"
        Me.ImportToolStripMenuItem.Size = New System.Drawing.Size(171, 22)
        Me.ImportToolStripMenuItem.Text = "Import"
        '
        'AboutToolStripMenuItem
        '
        Me.AboutToolStripMenuItem.ForeColor = System.Drawing.Color.White
        Me.AboutToolStripMenuItem.Image = Global.Minox_Player.My.Resources.Resources.info1
        Me.AboutToolStripMenuItem.Name = "AboutToolStripMenuItem"
        Me.AboutToolStripMenuItem.Size = New System.Drawing.Size(171, 22)
        Me.AboutToolStripMenuItem.Text = "About"
        '
        'Txt_TrackName
        '
        Me.Txt_TrackName.BackColor = System.Drawing.Color.Black
        Me.Txt_TrackName.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.Txt_TrackName.Enabled = False
        Me.Txt_TrackName.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.Txt_TrackName.ForeColor = System.Drawing.Color.Lime
        Me.Txt_TrackName.Location = New System.Drawing.Point(575, 12)
        Me.Txt_TrackName.Multiline = True
        Me.Txt_TrackName.Name = "Txt_TrackName"
        Me.Txt_TrackName.ReadOnly = True
        Me.Txt_TrackName.Size = New System.Drawing.Size(404, 24)
        Me.Txt_TrackName.TabIndex = 19
        Me.Txt_TrackName.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.Txt_TrackName.WordWrap = False
        '
        'NotifyIcon1
        '
        Me.NotifyIcon1.ContextMenuStrip = Me.MinoxAgent
        Me.NotifyIcon1.Icon = CType(resources.GetObject("NotifyIcon1.Icon"), System.Drawing.Icon)
        Me.NotifyIcon1.Text = "Minox Agent"
        Me.NotifyIcon1.Visible = True
        '
        'MinoxAgent
        '
        Me.MinoxAgent.BackColor = System.Drawing.Color.White
        Me.MinoxAgent.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.MinoxAgent.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.gnu_Play, Me.gnu_Pause, Me.gnu_Stop, Me.gnu_Next, Me.gnu_Previous, Me.mnPlaylist, Me.addMusic, Me.ToolStripSeparator1, Me.ourFacebook, Me.ourBlog, Me.aboutMinoxPlayer, Me.exitApp})
        Me.MinoxAgent.Name = "MinoxAgent"
        Me.MinoxAgent.OwnerItem = Me.minoxSubMenu
        Me.MinoxAgent.RenderMode = System.Windows.Forms.ToolStripRenderMode.System
        Me.MinoxAgent.ShowItemToolTips = False
        Me.MinoxAgent.Size = New System.Drawing.Size(188, 252)
        '
        'gnu_Play
        '
        Me.gnu_Play.Image = Global.Minox_Player.My.Resources.Resources.gnu_Play
        Me.gnu_Play.Name = "gnu_Play"
        Me.gnu_Play.Size = New System.Drawing.Size(187, 22)
        Me.gnu_Play.Text = "Play"
        '
        'gnu_Pause
        '
        Me.gnu_Pause.Image = Global.Minox_Player.My.Resources.Resources.gnu_Pause
        Me.gnu_Pause.Name = "gnu_Pause"
        Me.gnu_Pause.Size = New System.Drawing.Size(187, 22)
        Me.gnu_Pause.Text = "Pause"
        '
        'gnu_Stop
        '
        Me.gnu_Stop.Image = Global.Minox_Player.My.Resources.Resources.gnu_Stop
        Me.gnu_Stop.Name = "gnu_Stop"
        Me.gnu_Stop.Size = New System.Drawing.Size(187, 22)
        Me.gnu_Stop.Text = "Stop"
        '
        'gnu_Next
        '
        Me.gnu_Next.Image = Global.Minox_Player.My.Resources.Resources.gnome_Next
        Me.gnu_Next.Name = "gnu_Next"
        Me.gnu_Next.Size = New System.Drawing.Size(187, 22)
        Me.gnu_Next.Text = "Next"
        '
        'gnu_Previous
        '
        Me.gnu_Previous.Image = Global.Minox_Player.My.Resources.Resources.gnome_Previous
        Me.gnu_Previous.Name = "gnu_Previous"
        Me.gnu_Previous.Size = New System.Drawing.Size(187, 22)
        Me.gnu_Previous.Text = "Previous"
        '
        'mnPlaylist
        '
        Me.mnPlaylist.Image = Global.Minox_Player.My.Resources.Resources._1377649325_Playlist
        Me.mnPlaylist.Name = "mnPlaylist"
        Me.mnPlaylist.Size = New System.Drawing.Size(187, 22)
        Me.mnPlaylist.Text = "Playlist"
        '
        'addMusic
        '
        Me.addMusic.Image = Global.Minox_Player.My.Resources.Resources.gnu_Add
        Me.addMusic.Name = "addMusic"
        Me.addMusic.Size = New System.Drawing.Size(187, 22)
        Me.addMusic.Text = "Add files . . ."
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(184, 6)
        '
        'ourFacebook
        '
        Me.ourFacebook.Image = Global.Minox_Player.My.Resources.Resources.facebook2
        Me.ourFacebook.Name = "ourFacebook"
        Me.ourFacebook.Size = New System.Drawing.Size(187, 22)
        Me.ourFacebook.Text = "Visist us on Facebook"
        '
        'ourBlog
        '
        Me.ourBlog.Image = Global.Minox_Player.My.Resources.Resources.blogger1
        Me.ourBlog.Name = "ourBlog"
        Me.ourBlog.Size = New System.Drawing.Size(187, 22)
        Me.ourBlog.Text = "Our official blog"
        '
        'aboutMinoxPlayer
        '
        Me.aboutMinoxPlayer.Image = Global.Minox_Player.My.Resources.Resources.gnu_Info
        Me.aboutMinoxPlayer.Name = "aboutMinoxPlayer"
        Me.aboutMinoxPlayer.Size = New System.Drawing.Size(187, 22)
        Me.aboutMinoxPlayer.Text = "About"
        '
        'exitApp
        '
        Me.exitApp.Image = Global.Minox_Player.My.Resources.Resources.gnome_Exit
        Me.exitApp.Name = "exitApp"
        Me.exitApp.Size = New System.Drawing.Size(187, 22)
        Me.exitApp.Text = "Exit"
        '
        'minoxSubMenu
        '
        Me.minoxSubMenu.DropDown = Me.MinoxAgent
        Me.minoxSubMenu.Image = Global.Minox_Player.My.Resources.Resources.music_2__96x96
        Me.minoxSubMenu.Name = "minoxSubMenu"
        Me.minoxSubMenu.Size = New System.Drawing.Size(28, 20)
        Me.minoxSubMenu.ToolTipText = "Minox Menu"
        '
        'Timer2
        '
        Me.Timer2.Interval = 300
        '
        'volumeCounter
        '
        Me.volumeCounter.AutoSize = True
        Me.volumeCounter.BackColor = System.Drawing.Color.Transparent
        Me.volumeCounter.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.749999!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.volumeCounter.ForeColor = System.Drawing.Color.White
        Me.volumeCounter.Location = New System.Drawing.Point(3, 3)
        Me.volumeCounter.Name = "volumeCounter"
        Me.volumeCounter.Size = New System.Drawing.Size(20, 20)
        Me.volumeCounter.TabIndex = 1
        Me.volumeCounter.Text = "00"
        Me.volumeCounter.UseCompatibleTextRendering = True
        '
        'volumeBar
        '
        Me.volumeBar.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.volumeBar.BorderColor = System.Drawing.Color.Transparent
        Me.volumeBar.Label = Nothing
        Me.volumeBar.Location = New System.Drawing.Point(590, 393)
        Me.volumeBar.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.volumeBar.MaxValue = 100
        Me.volumeBar.Name = "volumeBar"
        Me.volumeBar.Orientation = System.Windows.Forms.Orientation.Vertical
        Me.volumeBar.Size = New System.Drawing.Size(21, 14)
        ColorLinearGradient2.ColorA = System.Drawing.Color.Lime
        ColorLinearGradient2.ColorB = System.Drawing.Color.Lime
        Me.volumeBar.SliderColorLow = ColorLinearGradient2
        Me.volumeBar.SliderSize = New System.Drawing.Size(10, 20)
        Me.volumeBar.SliderWidthHigh = 1.0!
        Me.volumeBar.SliderWidthLow = 1.0!
        Me.volumeBar.TabIndex = 29
        Me.volumeBar.TickThickness = 1.0!
        Me.volumeBar.Value = 0
        Me.volumeBar.ValueAdjusted = 0.0!
        Me.volumeBar.ValueDivisor = gTrackBar.gTrackBar.eValueDivisor.e1
        Me.volumeBar.ValueStrFormat = Nothing
        '
        'HScrollBar1
        '
        Me.HScrollBar1.LargeChange = 1
        Me.HScrollBar1.Location = New System.Drawing.Point(522, 451)
        Me.HScrollBar1.Name = "HScrollBar1"
        Me.HScrollBar1.Size = New System.Drawing.Size(184, 17)
        Me.HScrollBar1.TabIndex = 0
        '
        'menuPanel
        '
        Me.menuPanel.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.menuPanel.BackgroundImage = Global.Minox_Player.My.Resources.Resources.minoxMenu_Metal
        Me.menuPanel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.menuPanel.Controls.Add(Me.PictureBox1)
        Me.menuPanel.Controls.Add(Me.btn_Prev)
        Me.menuPanel.Controls.Add(Me.btn_Pause)
        Me.menuPanel.Controls.Add(Me.btn_Play)
        Me.menuPanel.Controls.Add(Me.btn_Next)
        Me.menuPanel.Controls.Add(Me.btn_Stop)
        Me.menuPanel.Controls.Add(Me.repeatPlay)
        Me.menuPanel.Controls.Add(Me.gTrackBar1)
        Me.menuPanel.Controls.Add(Me.maxValue)
        Me.menuPanel.Controls.Add(Me.minValue)
        Me.menuPanel.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.menuPanel.Location = New System.Drawing.Point(0, 383)
        Me.menuPanel.Name = "menuPanel"
        Me.menuPanel.Size = New System.Drawing.Size(408, 79)
        Me.menuPanel.TabIndex = 26
        '
        'PictureBox1
        '
        Me.PictureBox1.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox1.Image = Global.Minox_Player.My.Resources.Resources._1363568476_audio_volume_medium_panel
        Me.PictureBox1.Location = New System.Drawing.Point(286, 29)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(22, 22)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.PictureBox1.TabIndex = 32
        Me.PictureBox1.TabStop = False
        Me.ToolTip1.SetToolTip(Me.PictureBox1, "Volume Control")
        '
        'btn_Prev
        '
        Me.btn_Prev.BackColor = System.Drawing.Color.Transparent
        Me.btn_Prev.Image = Global.Minox_Player.My.Resources.Resources.blackPrevious
        Me.btn_Prev.Location = New System.Drawing.Point(102, 25)
        Me.btn_Prev.Name = "btn_Prev"
        Me.btn_Prev.Size = New System.Drawing.Size(32, 32)
        Me.btn_Prev.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.btn_Prev.TabIndex = 8
        Me.btn_Prev.TabStop = False
        Me.ToolTip1.SetToolTip(Me.btn_Prev, "Play previous track!")
        '
        'btn_Pause
        '
        Me.btn_Pause.BackColor = System.Drawing.Color.Transparent
        Me.btn_Pause.Image = Global.Minox_Player.My.Resources.Resources.blackPause
        Me.btn_Pause.Location = New System.Drawing.Point(137, 26)
        Me.btn_Pause.Name = "btn_Pause"
        Me.btn_Pause.Size = New System.Drawing.Size(32, 32)
        Me.btn_Pause.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.btn_Pause.TabIndex = 3
        Me.btn_Pause.TabStop = False
        Me.ToolTip1.SetToolTip(Me.btn_Pause, "Pause play!")
        '
        'btn_Play
        '
        Me.btn_Play.BackColor = System.Drawing.Color.Transparent
        Me.btn_Play.Image = Global.Minox_Player.My.Resources.Resources.playback_play_icon_48
        Me.btn_Play.Location = New System.Drawing.Point(168, 18)
        Me.btn_Play.Name = "btn_Play"
        Me.btn_Play.Size = New System.Drawing.Size(48, 48)
        Me.btn_Play.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.btn_Play.TabIndex = 2
        Me.btn_Play.TabStop = False
        Me.ToolTip1.SetToolTip(Me.btn_Play, "Start play!")
        '
        'btn_Next
        '
        Me.btn_Next.BackColor = System.Drawing.Color.Transparent
        Me.btn_Next.Image = Global.Minox_Player.My.Resources.Resources.blackNext
        Me.btn_Next.Location = New System.Drawing.Point(247, 26)
        Me.btn_Next.Name = "btn_Next"
        Me.btn_Next.Size = New System.Drawing.Size(32, 32)
        Me.btn_Next.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.btn_Next.TabIndex = 7
        Me.btn_Next.TabStop = False
        Me.ToolTip1.SetToolTip(Me.btn_Next, "Play next track!")
        '
        'btn_Stop
        '
        Me.btn_Stop.BackColor = System.Drawing.Color.Transparent
        Me.btn_Stop.Image = Global.Minox_Player.My.Resources.Resources.blackStop
        Me.btn_Stop.Location = New System.Drawing.Point(213, 27)
        Me.btn_Stop.Name = "btn_Stop"
        Me.btn_Stop.Size = New System.Drawing.Size(32, 32)
        Me.btn_Stop.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.btn_Stop.TabIndex = 4
        Me.btn_Stop.TabStop = False
        Me.ToolTip1.SetToolTip(Me.btn_Stop, "Stop player!")
        '
        'repeatPlay
        '
        Me.repeatPlay.AutoSize = True
        Me.repeatPlay.ForeColor = System.Drawing.Color.White
        Me.repeatPlay.Location = New System.Drawing.Point(522, 78)
        Me.repeatPlay.Name = "repeatPlay"
        Me.repeatPlay.Size = New System.Drawing.Size(89, 17)
        Me.repeatPlay.TabIndex = 31
        Me.repeatPlay.Text = "repeatTracks"
        Me.repeatPlay.UseVisualStyleBackColor = True
        Me.repeatPlay.Visible = False
        '
        'gTrackBar1
        '
        Me.gTrackBar1.BackColor = System.Drawing.Color.Transparent
        Me.gTrackBar1.Label = Nothing
        Me.gTrackBar1.Location = New System.Drawing.Point(1, 0)
        Me.gTrackBar1.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.gTrackBar1.Name = "gTrackBar1"
        Me.gTrackBar1.ShowFocus = False
        Me.gTrackBar1.Size = New System.Drawing.Size(407, 24)
        Me.gTrackBar1.SliderWidthHigh = 1.0!
        Me.gTrackBar1.SliderWidthLow = 1.0!
        Me.gTrackBar1.TabIndex = 29
        Me.gTrackBar1.TickColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.gTrackBar1.TickThickness = 1.0!
        Me.ToolTip1.SetToolTip(Me.gTrackBar1, "Seek trackbar with your mouse!")
        Me.gTrackBar1.Value = 0
        Me.gTrackBar1.ValueAdjusted = 0.0!
        Me.gTrackBar1.ValueDivisor = gTrackBar.gTrackBar.eValueDivisor.e1
        Me.gTrackBar1.ValueStrFormat = Nothing
        '
        'maxValue
        '
        Me.maxValue.AutoSize = True
        Me.maxValue.BackColor = System.Drawing.Color.Transparent
        Me.maxValue.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.749999!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.maxValue.ForeColor = System.Drawing.Color.White
        Me.maxValue.Location = New System.Drawing.Point(331, 28)
        Me.maxValue.Name = "maxValue"
        Me.maxValue.Size = New System.Drawing.Size(40, 20)
        Me.maxValue.TabIndex = 10
        Me.maxValue.Text = "00:00"
        Me.maxValue.UseCompatibleTextRendering = True
        '
        'minValue
        '
        Me.minValue.AutoSize = True
        Me.minValue.BackColor = System.Drawing.Color.Transparent
        Me.minValue.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.749999!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.minValue.ForeColor = System.Drawing.Color.White
        Me.minValue.Location = New System.Drawing.Point(12, 29)
        Me.minValue.Name = "minValue"
        Me.minValue.Size = New System.Drawing.Size(40, 20)
        Me.minValue.TabIndex = 11
        Me.minValue.Text = "00:00"
        Me.minValue.UseCompatibleTextRendering = True
        '
        'trackBarSeekBar
        '
        Me.trackBarSeekBar.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.trackBarSeekBar.Location = New System.Drawing.Point(809, 42)
        Me.trackBarSeekBar.Name = "trackBarSeekBar"
        Me.trackBarSeekBar.Size = New System.Drawing.Size(170, 45)
        Me.trackBarSeekBar.TabIndex = 4
        Me.trackBarSeekBar.TickStyle = System.Windows.Forms.TickStyle.None
        '
        'Timer3
        '
        Me.Timer3.Interval = 1
        '
        'Timer4
        '
        Me.Timer4.Enabled = True
        '
        'Timer5
        '
        Me.Timer5.Enabled = True
        Me.Timer5.Interval = 50
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.FileName = "OpenFileDialog1 |*.mp3 |*.mp3"
        '
        'btn_PlayList
        '
        Me.btn_PlayList.Image = Global.Minox_Player.My.Resources.Resources.playListBlack
        Me.btn_PlayList.Location = New System.Drawing.Point(239, 569)
        Me.btn_PlayList.Name = "btn_PlayList"
        Me.btn_PlayList.Size = New System.Drawing.Size(32, 32)
        Me.btn_PlayList.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.btn_PlayList.TabIndex = 9
        Me.btn_PlayList.TabStop = False
        '
        'btn_Volume
        '
        Me.btn_Volume.Image = Global.Minox_Player.My.Resources.Resources.blackVolume
        Me.btn_Volume.Location = New System.Drawing.Point(277, 569)
        Me.btn_Volume.Name = "btn_Volume"
        Me.btn_Volume.Size = New System.Drawing.Size(32, 32)
        Me.btn_Volume.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.btn_Volume.TabIndex = 3
        Me.btn_Volume.TabStop = False
        '
        'Play1
        '
        Me.Play1.BackColor = System.Drawing.Color.White
        Me.Play1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Play1.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Play1.FlatAppearance.BorderSize = 5
        Me.Play1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Lime
        Me.Play1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Lime
        Me.Play1.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Play1.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.Play1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Play1.Image = Global.Minox_Player.My.Resources.Resources.play__1_
        Me.Play1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Play1.Location = New System.Drawing.Point(827, 151)
        Me.Play1.Name = "Play1"
        Me.Play1.Size = New System.Drawing.Size(92, 10)
        Me.Play1.TabIndex = 0
        Me.Play1.Text = "       Play"
        Me.Play1.UseVisualStyleBackColor = False
        Me.Play1.Visible = False
        '
        'Next1
        '
        Me.Next1.BackColor = System.Drawing.Color.White
        Me.Next1.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Next1.FlatAppearance.BorderSize = 5
        Me.Next1.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Next1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Lime
        Me.Next1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Lime
        Me.Next1.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Next1.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.Next1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Next1.Image = Global.Minox_Player.My.Resources.Resources.next__1_
        Me.Next1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Next1.Location = New System.Drawing.Point(827, 255)
        Me.Next1.Name = "Next1"
        Me.Next1.Size = New System.Drawing.Size(92, 10)
        Me.Next1.TabIndex = 16
        Me.Next1.Text = "        Next"
        Me.Next1.UseVisualStyleBackColor = False
        Me.Next1.Visible = False
        '
        'slideDown
        '
        Me.slideDown.BackColor = System.Drawing.Color.Black
        Me.slideDown.Image = Global.Minox_Player.My.Resources.Resources.backwardWhite
        Me.slideDown.Location = New System.Drawing.Point(755, 229)
        Me.slideDown.Name = "slideDown"
        Me.slideDown.Size = New System.Drawing.Size(16, 16)
        Me.slideDown.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.slideDown.TabIndex = 28
        Me.slideDown.TabStop = False
        Me.slideDown.Visible = False
        '
        'slideUp
        '
        Me.slideUp.BackColor = System.Drawing.Color.Black
        Me.slideUp.Image = Global.Minox_Player.My.Resources.Resources.forwardWhite
        Me.slideUp.Location = New System.Drawing.Point(777, 229)
        Me.slideUp.Name = "slideUp"
        Me.slideUp.Size = New System.Drawing.Size(16, 16)
        Me.slideUp.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.slideUp.TabIndex = 27
        Me.slideUp.TabStop = False
        '
        'Stop1
        '
        Me.Stop1.BackColor = System.Drawing.Color.White
        Me.Stop1.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Stop1.FlatAppearance.BorderSize = 5
        Me.Stop1.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Stop1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Lime
        Me.Stop1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Lime
        Me.Stop1.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Stop1.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.Stop1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Stop1.Image = Global.Minox_Player.My.Resources.Resources.box_orange
        Me.Stop1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Stop1.Location = New System.Drawing.Point(827, 184)
        Me.Stop1.Name = "Stop1"
        Me.Stop1.Size = New System.Drawing.Size(92, 10)
        Me.Stop1.TabIndex = 2
        Me.Stop1.Text = "       Stop  "
        Me.Stop1.UseVisualStyleBackColor = False
        Me.Stop1.Visible = False
        '
        'btn_Add
        '
        Me.btn_Add.Image = Global.Minox_Player.My.Resources.Resources.blackImport
        Me.btn_Add.Location = New System.Drawing.Point(91, 569)
        Me.btn_Add.Name = "btn_Add"
        Me.btn_Add.Size = New System.Drawing.Size(32, 32)
        Me.btn_Add.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.btn_Add.TabIndex = 5
        Me.btn_Add.TabStop = False
        '
        'Prev1
        '
        Me.Prev1.BackColor = System.Drawing.Color.White
        Me.Prev1.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Prev1.FlatAppearance.BorderSize = 5
        Me.Prev1.FlatAppearance.CheckedBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Prev1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Lime
        Me.Prev1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Lime
        Me.Prev1.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Prev1.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.Prev1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Prev1.Image = Global.Minox_Player.My.Resources.Resources.previous__1_
        Me.Prev1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Prev1.Location = New System.Drawing.Point(827, 218)
        Me.Prev1.Name = "Prev1"
        Me.Prev1.Size = New System.Drawing.Size(92, 10)
        Me.Prev1.TabIndex = 17
        Me.Prev1.Text = "         Preview"
        Me.Prev1.UseVisualStyleBackColor = False
        Me.Prev1.Visible = False
        '
        'FullMode
        '
        Me.FullMode.BackColor = System.Drawing.Color.Black
        Me.FullMode.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.FullMode.ForeColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.FullMode.Image = Global.Minox_Player.My.Resources.Resources.window_full_screen_icon
        Me.FullMode.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.FullMode.Location = New System.Drawing.Point(827, 122)
        Me.FullMode.Name = "FullMode"
        Me.FullMode.Size = New System.Drawing.Size(92, 10)
        Me.FullMode.TabIndex = 10
        Me.FullMode.UseVisualStyleBackColor = False
        Me.FullMode.Visible = False
        '
        'minoxHead
        '
        Me.minoxHead.BackColor = System.Drawing.Color.Transparent
        Me.minoxHead.BackgroundImage = Global.Minox_Player.My.Resources.Resources.minoxMenu_Metal
        Me.minoxHead.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.minoxHead.Controls.Add(Me.exitProgram)
        Me.minoxHead.Controls.Add(Me.minoxLogo)
        Me.minoxHead.Controls.Add(Me.minimizeProgram)
        Me.minoxHead.Controls.Add(Me.MenuStrip1)
        Me.minoxHead.Dock = System.Windows.Forms.DockStyle.Top
        Me.minoxHead.Location = New System.Drawing.Point(0, 0)
        Me.minoxHead.Name = "minoxHead"
        Me.minoxHead.Size = New System.Drawing.Size(408, 35)
        Me.minoxHead.TabIndex = 29
        '
        'exitProgram
        '
        Me.exitProgram.AutoSize = True
        Me.exitProgram.BackColor = System.Drawing.Color.Transparent
        Me.exitProgram.Font = New System.Drawing.Font("Microsoft Sans Serif", 17.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.exitProgram.ForeColor = System.Drawing.Color.White
        Me.exitProgram.Location = New System.Drawing.Point(381, -1)
        Me.exitProgram.Name = "exitProgram"
        Me.exitProgram.Size = New System.Drawing.Size(20, 32)
        Me.exitProgram.TabIndex = 32
        Me.exitProgram.Text = "x"
        Me.ToolTip1.SetToolTip(Me.exitProgram, "Close Minox Player!")
        Me.exitProgram.UseCompatibleTextRendering = True
        '
        'minoxLogo
        '
        Me.minoxLogo.AutoSize = True
        Me.minoxLogo.BackColor = System.Drawing.Color.Transparent
        Me.minoxLogo.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.minoxLogo.ForeColor = System.Drawing.Color.White
        Me.minoxLogo.Location = New System.Drawing.Point(142, 5)
        Me.minoxLogo.Name = "minoxLogo"
        Me.minoxLogo.Size = New System.Drawing.Size(95, 22)
        Me.minoxLogo.TabIndex = 30
        Me.minoxLogo.Text = "Minox Player"
        Me.minoxLogo.UseCompatibleTextRendering = True
        '
        'minimizeProgram
        '
        Me.minimizeProgram.AutoSize = True
        Me.minimizeProgram.BackColor = System.Drawing.Color.Transparent
        Me.minimizeProgram.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.minimizeProgram.ForeColor = System.Drawing.Color.White
        Me.minimizeProgram.Location = New System.Drawing.Point(25, -1)
        Me.minimizeProgram.Name = "minimizeProgram"
        Me.minimizeProgram.Size = New System.Drawing.Size(19, 37)
        Me.minimizeProgram.TabIndex = 31
        Me.minimizeProgram.Text = "-"
        Me.ToolTip1.SetToolTip(Me.minimizeProgram, "Minimize to system tray!")
        Me.minimizeProgram.UseCompatibleTextRendering = True
        '
        'MenuStrip1
        '
        Me.MenuStrip1.BackColor = System.Drawing.Color.Transparent
        Me.MenuStrip1.Dock = System.Windows.Forms.DockStyle.None
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.minoxSubMenu})
        Me.MenuStrip1.Location = New System.Drawing.Point(-5, 5)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(36, 24)
        Me.MenuStrip1.TabIndex = 34
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'nowPlayling
        '
        Me.nowPlayling.AutoSize = True
        Me.nowPlayling.BackColor = System.Drawing.Color.Transparent
        Me.nowPlayling.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.25!, System.Drawing.FontStyle.Bold)
        Me.nowPlayling.ForeColor = System.Drawing.Color.White
        Me.nowPlayling.Location = New System.Drawing.Point(432, 357)
        Me.nowPlayling.Name = "nowPlayling"
        Me.nowPlayling.Size = New System.Drawing.Size(171, 21)
        Me.nowPlayling.TabIndex = 30
        Me.nowPlayling.Text = "Welcome to Minox Player"
        Me.nowPlayling.UseCompatibleTextRendering = True
        '
        'myVolumeBar
        '
        Me.myVolumeBar.BackColor = System.Drawing.Color.Transparent
        Me.myVolumeBar.BorderColor = System.Drawing.SystemColors.ActiveBorder
        Me.myVolumeBar.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.myVolumeBar.ForeColor = System.Drawing.Color.FromArgb(CType(CType(123, Byte), Integer), CType(CType(125, Byte), Integer), CType(CType(123, Byte), Integer))
        Me.myVolumeBar.IndentHeight = 6
        Me.myVolumeBar.LargeChange = 10
        Me.myVolumeBar.Location = New System.Drawing.Point(0, 21)
        Me.myVolumeBar.Maximum = 100
        Me.myVolumeBar.Minimum = 0
        Me.myVolumeBar.Name = "myVolumeBar"
        Me.myVolumeBar.Orientation = System.Windows.Forms.Orientation.Vertical
        Me.myVolumeBar.Size = New System.Drawing.Size(60, 111)
        Me.myVolumeBar.TabIndex = 32
        Me.myVolumeBar.TextTickStyle = System.Windows.Forms.TickStyle.BottomRight
        Me.myVolumeBar.TickColor = System.Drawing.Color.Transparent
        Me.myVolumeBar.TickFrequency = 100
        Me.myVolumeBar.TickHeight = 4
        Me.myVolumeBar.TickStyle = System.Windows.Forms.TickStyle.BottomRight
        Me.myVolumeBar.TrackerColor = System.Drawing.Color.Blue
        Me.myVolumeBar.TrackerSize = New System.Drawing.Size(16, 16)
        Me.myVolumeBar.TrackLineColor = System.Drawing.Color.Black
        Me.myVolumeBar.TrackLineHeight = 5
        Me.myVolumeBar.Value = 50
        '
        'Timer6
        '
        Me.Timer6.Enabled = True
        Me.Timer6.Interval = 50
        '
        'trackStatus
        '
        Me.trackStatus.AutoSize = True
        Me.trackStatus.BackColor = System.Drawing.Color.Transparent
        Me.trackStatus.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.trackStatus.ForeColor = System.Drawing.Color.White
        Me.trackStatus.Location = New System.Drawing.Point(0, 355)
        Me.trackStatus.Name = "trackStatus"
        Me.trackStatus.Size = New System.Drawing.Size(94, 22)
        Me.trackStatus.TabIndex = 33
        Me.trackStatus.Text = "Now playing:"
        Me.trackStatus.UseCompatibleTextRendering = True
        '
        'myVolumePanel
        '
        Me.myVolumePanel.BackColor = System.Drawing.Color.Transparent
        Me.myVolumePanel.BackgroundImage = Global.Minox_Player.My.Resources.Resources.minoxVolume_Metal4
        Me.myVolumePanel.Controls.Add(Me.myVolumeBar)
        Me.myVolumePanel.Controls.Add(Me.volumeCounter)
        Me.myVolumePanel.Location = New System.Drawing.Point(282, 279)
        Me.myVolumePanel.Name = "myVolumePanel"
        Me.myVolumePanel.Size = New System.Drawing.Size(31, 133)
        Me.myVolumePanel.TabIndex = 34
        Me.myVolumePanel.Visible = False
        '
        'MediaPlayer
        '
        Me.MediaPlayer.AllowDrop = True
        Me.MediaPlayer.Enabled = True
        Me.MediaPlayer.Location = New System.Drawing.Point(897, 93)
        Me.MediaPlayer.Name = "MediaPlayer"
        Me.MediaPlayer.OcxState = CType(resources.GetObject("MediaPlayer.OcxState"), System.Windows.Forms.AxHost.State)
        Me.MediaPlayer.Size = New System.Drawing.Size(82, 23)
        Me.MediaPlayer.TabIndex = 6
        '
        'Timer7
        '
        Me.Timer7.Interval = 500
        '
        'Timer8
        '
        Me.Timer8.Interval = 2000
        '
        'Form1
        '
        Me.AllowDrop = True
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.HotTrack
        Me.BackgroundImage = Global.Minox_Player.My.Resources.Resources.minoxCover_Metal1
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(408, 462)
        Me.ContextMenuStrip = Me.Styler
        Me.Controls.Add(Me.trackStatus)
        Me.Controls.Add(Me.myVolumePanel)
        Me.Controls.Add(Me.volumeBar)
        Me.Controls.Add(Me.minoxHead)
        Me.Controls.Add(Me.HScrollBar1)
        Me.Controls.Add(Me.btn_PlayList)
        Me.Controls.Add(Me.menuPanel)
        Me.Controls.Add(Me.btn_Volume)
        Me.Controls.Add(Me.Txt_TrackName)
        Me.Controls.Add(Me.Play1)
        Me.Controls.Add(Me.Next1)
        Me.Controls.Add(Me.slideDown)
        Me.Controls.Add(Me.slideUp)
        Me.Controls.Add(Me.Stop1)
        Me.Controls.Add(Me.btn_Add)
        Me.Controls.Add(Me.trackBarSeekBar)
        Me.Controls.Add(Me.Prev1)
        Me.Controls.Add(Me.FullMode)
        Me.Controls.Add(Me.MediaPlayer)
        Me.Controls.Add(Me.nowPlayling)
        Me.DoubleBuffered = True
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.KeyPreview = True
        Me.MainMenuStrip = Me.MenuStrip1
        Me.MaximizeBox = False
        Me.Name = "Form1"
        Me.ShowIcon = False
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Minox Player"
        Me.TransparencyKey = System.Drawing.Color.Green
        Me.Styler.ResumeLayout(False)
        Me.MinoxAgent.ResumeLayout(False)
        Me.menuPanel.ResumeLayout(False)
        Me.menuPanel.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btn_Prev, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btn_Pause, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btn_Play, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btn_Next, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btn_Stop, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.trackBarSeekBar, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btn_PlayList, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btn_Volume, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.slideDown, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.slideUp, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btn_Add, System.ComponentModel.ISupportInitialize).EndInit()
        Me.minoxHead.ResumeLayout(False)
        Me.minoxHead.PerformLayout()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.myVolumePanel.ResumeLayout(False)
        Me.myVolumePanel.PerformLayout()
        CType(Me.MediaPlayer, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Play1 As System.Windows.Forms.Button
    Friend WithEvents Stop1 As System.Windows.Forms.Button
    Friend WithEvents MediaPlayer As AxWMPLib.AxWindowsMediaPlayer
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents FullMode As System.Windows.Forms.Button
    Friend WithEvents Styler As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents ColorDialog1 As System.Windows.Forms.ColorDialog
    Friend WithEvents Next1 As System.Windows.Forms.Button
    Friend WithEvents Prev1 As System.Windows.Forms.Button
    Friend WithEvents PlaylistToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ImportToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AboutToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Txt_TrackName As System.Windows.Forms.TextBox
    Friend WithEvents NotifyIcon1 As System.Windows.Forms.NotifyIcon
    Friend WithEvents MinoxAgent As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents Timer2 As System.Windows.Forms.Timer
    Friend WithEvents volumeCounter As System.Windows.Forms.Label
    Friend WithEvents HScrollBar1 As System.Windows.Forms.HScrollBar
    Friend WithEvents Timer3 As System.Windows.Forms.Timer
    Friend WithEvents menuPanel As System.Windows.Forms.Panel
    Friend WithEvents minValue As System.Windows.Forms.Label
    Friend WithEvents maxValue As System.Windows.Forms.Label
    Friend WithEvents btn_Volume As System.Windows.Forms.PictureBox
    Friend WithEvents btn_Prev As System.Windows.Forms.PictureBox
    Friend WithEvents btn_Next As System.Windows.Forms.PictureBox
    Friend WithEvents btn_Pause As System.Windows.Forms.PictureBox
    Friend WithEvents btn_Play As System.Windows.Forms.PictureBox
    Friend WithEvents btn_Add As System.Windows.Forms.PictureBox
    Friend WithEvents btn_Stop As System.Windows.Forms.PictureBox
    Friend WithEvents Timer4 As System.Windows.Forms.Timer
    Friend WithEvents Timer5 As System.Windows.Forms.Timer
    Friend WithEvents slideUp As System.Windows.Forms.PictureBox
    Friend WithEvents slideDown As System.Windows.Forms.PictureBox
    Friend WithEvents OpenFileDialog1 As System.Windows.Forms.OpenFileDialog
    Friend WithEvents trackBarSeekBar As System.Windows.Forms.TrackBar
    Friend WithEvents btn_PlayList As System.Windows.Forms.PictureBox
    Friend WithEvents ThemesAndSkinsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents gTrackBar1 As gTrackBar.gTrackBar
    Friend WithEvents volumeBar As gTrackBar.gTrackBar
    Friend WithEvents PlayModeToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents repeatPlay As System.Windows.Forms.CheckBox
    Friend WithEvents minoxHead As System.Windows.Forms.Panel
    Friend WithEvents minoxLogo As System.Windows.Forms.Label
    Friend WithEvents minimizeProgram As System.Windows.Forms.Label
    Friend WithEvents exitProgram As System.Windows.Forms.Label
    Friend WithEvents nowPlayling As System.Windows.Forms.Label
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents myVolumeBar As XComponent.SliderBar.MACTrackBar
    Friend WithEvents Timer6 As System.Windows.Forms.Timer
    Friend WithEvents trackStatus As System.Windows.Forms.Label
    Friend WithEvents metalTheme As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PlaylistColorToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TextColorwToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents pinkThemes As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents orangeThema As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents brownThema As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BlackToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DodgerBlueToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents WhiteToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents WhiteToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RedToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DodgerBlueToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BlackToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents gnu_Play As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents gnu_Pause As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents gnu_Next As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents gnu_Previous As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents addMusic As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents gnu_Stop As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ourFacebook As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ourBlog As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents aboutMinoxPlayer As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents exitApp As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents minoxSubMenu As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LimeToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents myVolumePanel As System.Windows.Forms.Panel
    Friend WithEvents technologyBlue As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents darkGray As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents techOrange As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents purpleThema As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnPlaylist As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AddFolderToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolTip1 As System.Windows.Forms.ToolTip
    Friend WithEvents blackThemaX As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents flatBrown_Thema As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Timer7 As System.Windows.Forms.Timer
    Friend WithEvents Timer8 As System.Windows.Forms.Timer
    Friend WithEvents greenLime As System.Windows.Forms.ToolStripMenuItem

End Class
